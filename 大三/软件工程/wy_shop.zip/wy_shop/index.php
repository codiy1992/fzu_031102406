<?php
define('otion_path','./otionPHP');//定义框架路径

define('app_path','./Home');//定义项目路径

require(otion_path.'/otionPHP.php');//加载框架入口文件
