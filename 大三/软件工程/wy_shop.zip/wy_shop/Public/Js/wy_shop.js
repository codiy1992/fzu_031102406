addEventListener("load", function() { 
 setTimeout(hideURLbar, 0);
 }, false);

addEventListener("load", function(){			 		
var isIE = false;			 		
var uaArray = (navigator.userAgent).split("; ");			 		
for(var i=0; i<uaArray.length; i++){
if(uaArray[i].split("/")[0] == "IEMobile"){
isIE = true;
}
}			 		
if(docCookies.hasItem("top_advt") == true){		
document.getElementById("top_advt").style.display = "none";	
}else{	
sendRequest("http://m.55tuan.com/GetActive_Ajax.ashx")			 		
if(isIE == true){
initIEAdvt();
}else{							       
initIEAdvt();
}
}
}, false
);

var catgoryTags =
{
	"全部♥http://m.55tuan.com/fuzhou/all":"分类",
	"今日新单♥http://m.55tuan.com/fuzhou/todaynewgoods":"",
		"美食":["全部♥http://m.55tuan.com/fuzhou/meishi",
		"火锅♥http://m.55tuan.com/fuzhou/huoguo",
		"母婴文教♥http://m.55tuan.com/fuzhou/muyingyongpin"]
};
var districtTags =
{
	"全部♥http://m.55tuan.com/fuzhou/meishi":"城区",
	"鼓楼区":["全部♥http://m.55tuan.com/fuzhou/meishi/gulou",
	"东街口♥http://m.55tuan.com/fuzhou/meishi/dongjiekou",
	"福清市♥http://m.55tuan.com/fuzhou/meishi/fuqing":""
};
var sortTags =
{
	"默认排序♥http://m.55tuan.com/fuzhou/meishi":"排序",
	"价格":["从低到高♥http://m.55tuan.com/fuzhou/meishi?sort=3",
	"从高到低♥http://m.55tuan.com/fuzhou/meishi?sort=4"],
	"购买最多♥http://m.55tuan.com/fuzhou/meishi?sort=2":"",
	"最新发布♥http://m.55tuan.com/fuzhou/meishi?sort=5":""
};