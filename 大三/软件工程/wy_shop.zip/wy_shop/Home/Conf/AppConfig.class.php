<?php
class AppConfig
{
 public function index()
 {
 return array(
 //配置项
 'db_type'=>'mysql',
          // 数据库类型（可选项是'mysql','sqlite'）
 'db_connect_way'=>'mysql',
          //连接数据库的方式（可选项是'mysql','sqlite','pdo','adodb'）
//'sqlite_db_path'=>,
         //SQLite数据库文件相对于主入口文件的路径(前提是设置了'db_type'项的值为'sqlite'且开启了php的sqlite扩展)




'db_host'=>'localhost',// 服务器地址
'db_name'=>'wy_shop', // 数据库名
'db_user'=>'root',// 用户名
'db_psw'=>'',// 密码
//'db_port'=>,//端口号
'db_charset'=>'utf8',//数据库字符集编码
'db_prefix'=>'wy_',// 数据库表前缀（若留空表示不使用表前缀）
//'db_fetch_type'=>,
         //返回数据库查询结果的形式（'assoc'表示只以关联数组形式返回，'num'表示只以索引数组形式返回，'both'表示同时以关联数组和索引数组的形式返回）

//'__PUBLIC__'=>,//当前项目的公共目录
//'__CSS__'=>,//当前项目的公共目录下的css文件夹
//'__JS__'=>,//当前项目的公共目录下的js文件夹
//'__IMAGE__'=>,//当前项目的公共目录的image文件夹

//'__ROOT__'=>,//当前项目的路径
//'__APP__'=>,//当前应用的路径
//'__URL__'=>,//当前模块的路径
//'__SELF__'=>,//当前模块的路径
//'__ACTION__'=>,//当前方法的路径


//'tpl_path'=>,//模板文件存放路径
//'com_path'=>,//模板编译后文件存放路径
//'tmpl_l_delim'=>,//模板文件的左定界符
//'tmpl_r_delim'=>,//模板文件的右定界符
//'tmpl_suffix'=>,//默认的模板文件后缀名
//'theme_list'=>,//模板主题列表
//'default_theme'=>,//默认的模板主题

//'open_staticwp'=>,//是否启用页面静态化
//'staticwp_path'=>,//静态页面文件存放路径
//'staticwp_save_time'=>,//静态页面自动更新周期
//'staticwp_pages'=>,//需要进行静态化处理的页面


//'open_cache'=>,//是否开启memcache缓存
//'memcache_host'=>,//memcache缓存的主机地址
//'memcache_port'=>,//memcache缓存的端口号
//'cache_encrypt'=>,//是否对memcache缓存内容进行加密
//'cache_save_time'=>,//memcache缓存生存时间
//'save_session_in_cache'=>,//是否将session值写入memcache缓存

//'open_rewrite'=>,//是否启用url重写
//'import_doc_hidden'=>,//是否通过url重写隐藏主入口文件名
//'url_suffix'=>,//使用伪静态时允许的url后缀名
//'anti_hotlinking'=>,//需要作防盗链处理的文件夹

//'log_record'=>,//是否开启日志记录功能
//'log_path'=>,//日志文件存放路径
//'log_level'=>,//日志记录级别
//'log_OtionException'=>,//是否在抛出框架定义的OtionException异常对象时将异常信息记入日志

//'crypt_key'=>,//使用Common类提供的encrypt和decrypt加密解密时的秘钥
//'display_OtionException'=>,//是否显示异常信息（默认开启，项目正式发布后可以关闭）
//'display_errors'=>,//是否显示错误信息（默认开启，项目正式发布后可以关闭）
//'url_param_separtor'=>,//url中参数的分隔符
//'check_get_post_sql'=>,//是否自动对所有的get值和post值作防sql注入处理
//'token_open'=>,//是否开启表单令牌验证
 );

 }
}

