<?php
class CommonAction extends Action
{
	// ========检测是否为非法访问========
	function check_login_state()
	{
		$r = 1;
		
		if (! isset ( $_SESSION ['user_name'] ) || ! isset ( $_SESSION ['user_shell'] ))
			$r = 0;
		else
		{
			$user = M ( 'user' );
			$row = $user->where ( array (
					'name' => $_SESSION ['user_name'] 
			) )->find ();
			
			if ($_SESSION ['user_shell'] != md5 ( $row ['name'] . $row ['password'] ))
				$r = 0;
		}
		
		if ($r == 0)
		{
			echo "<script>alert('您无权访问此页面！')</script>";
			session_destroy ();
			$this->redirect ( 'Index/index' );
			exit ();
		}
	}
}
