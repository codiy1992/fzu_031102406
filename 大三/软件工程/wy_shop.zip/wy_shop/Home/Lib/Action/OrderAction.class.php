<?php
  class OrderAction extends Action
  {
function order_index()//显示订单表单
{
	if(!isset($_SESSION['user_name']))
	{
	echo"<script>alert('您还未登录,请先登录');</script>";
	$this->redirect('User/login_index');
	}
	else
	{
	R('Common/check_login_state');//检测用户登录状态
	$id=$_GET['id'];
	$g=M('goods');
	$r=$g->where(array('id'=>$id))->find();
	$this->assign('goods_msg',$r);//商品详情

	date_default_timezone_set('Asia/Shanghai');
	$this->assign('time',date('Y-m-d H:i:s'));
	$this->display();
	}
}
function order_deal()//订单处理
{
	R('Common/check_login_state');//检测用户登录状态
	$id=$_POST['id'];
	$num=$_POST['num'];
	//$bank=$_POST['pay_method'];
	date_default_timezone_set('Asia/Shanghai');
    $data=array(
	'user_name'=>$_SESSION['user_name'],
	'goods_id'=>$id,	
	'time'=>date('Y-m-d H:i:s'),
	'num'=>$num,
	//'bank'=>$bank
	);
	$o=M('Order');
	$o->data($data)->add();
	$order_id=$o->last_insert_id();
	echo"<script>alert('订单提交成功,您的订单号是:".$order_id.",请持订单号到餐厅消费并付款');</script>";
	$this->redirect('Index/index');
}
function my_order_list()//个人订单管理
{
	if(!isset($_SESSION['user_name']))
	{
	echo"<script>alert('您还未登录,请先登录');</script>";
	$this->redirect('User/login_index');
	}
	else
	{
	R('Common/check_login_state');//检测用户登录状态

	$o=M();
	$r=$o->query("select a.*,b.title,b.stock_price from wy_order as a left join wy_goods as b on a.goods_id=b.id where a.user_name='".$_SESSION['user_name']."' order by a.time desc");

	$this->assign('order_list',$r);//订单列表

	$this->display();
	}
}
function delete()//删除订单
{
R('Common/check_login_state');//检测用户登录状态
$id=$_GET['id'];
$o=M('order');
$o->where(array('id'=>$id))->delete();
echo"<script>alert('删除成功');</script>";
$this->redirect('Order/my_order_list');
}
function edit_index()//修改订单表单
{
R('Common/check_login_state');//检测用户登录状态
$o=M();
$r=$o->query("select a.*,b.title,b.stock_price from wy_order as a left join wy_goods as b on a.goods_id=b.id where a.id='".$_GET['id']."' order by a.time desc");
$this->assign('order_info',$r[0]);//订单信息

date_default_timezone_set('Asia/Shanghai');
$this->assign('time',date('Y-m-d H:i:s'));
$this->display();
}
function edit_deal()//修改订单处理
{
R('Common/check_login_state');//检测用户登录状态
$o=M('Order');
$data=array(
'num'=>$_POST['num']
);
$o->data($data)->where(array('id'=>$_POST['id']))->save();
echo"<script>alert('修改成功');</script>";
$this->redirect('Order/my_order_list');
}
  }