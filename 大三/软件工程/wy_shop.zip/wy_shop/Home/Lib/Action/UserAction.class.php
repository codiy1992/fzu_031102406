<?php
class UserAction extends Action
{
function login_index()//==显示登录表单
{
  $this->display();
}
function create_verify() // ==生成验证码
{
		$image = Image::getInstance ();
		$image->buildImageVerify ( 4, '0', 'png', 30, 30, 'verify' );
}
function login()//==登录验证
{
        $name=$_POST['name'];
        $psw=$_POST['password'];
        $verify=$_POST['verify'];
		if($_SESSION['verify']!=md5(strtolower($verify)))
		{
		echo "<script>alert('验证码不正确');history.go(-1);</script>";
		}
        else
		{
		 $user =M('user');

		$row = $user->where ( array ('name' => $name ) )->find ();
		
		if (! is_array ( $row ))
		{
		 echo "<script>alert('用户名不存在');history.go(-1);</script>";
		}
		else if ($row ['password'] != md5 ( md5 ( $psw ) ))
		{
		 echo "<script>alert('用户名或密码输入有误');history.go(-1);</script>";
		}
		else
		{
		 $_SESSION ['user_name'] = $name;
	     $_SESSION ['user_shell'] = md5 ($row['name'].$row['password']);
		 echo "<script>alert('登陆成功');</script>";
		 $this->redirect ( 'Index/index' );		
		}
		}
}
function findpsw_receive()//接收找回密码请求
{
  $u=M('user');
  $row=$u->where(array('name'=>$_GET['user_name']))->find();
  if(!is_array($row))
	  echo"<script>alert('用户名不存在');history.go(-1);</script>";
  else
  {
  $code=base64_encode($row['name'].','.md5($row['name'].$row['password']));
 
  $sm=SendEmail::getInstance();
  $r=$sm->index('1973718688@qq.com','xiaoabc123123',$row['email'],'本邮件用于重置您在我要团购网中的密码','请点击以下链接重置您的密码:'.__URL__.'/findpsw_index/code/'.$code.'<br>如果您没有请求重置您在我要团购网中的密码，请不用理会此封邮件，直接删除！');
  if($r)
	  echo"<script>alert('我们已将用于重置密码的邮件发送到您注册时使用的邮箱".$row['email'].",请注意查收！');</script>";
  $this->redirect('Index/index');
  }
}
function findpsw_index()//验证找回密码链接
{
  $code=$_GET['code'];
  $arr=explode(',',base64_decode($code));
  $u=M('user');
  $row=$u->where(array('name'=>$arr[0]))->find();
  if(md5($row['name'].$row['password'])!=$arr[1])
  {
  echo"<script>alert('非法访问!');</script>";
  $this->redirect('Index/index');
  }
  else
  {
  $this->assign('user_name',$arr[0]);
  $this->display();
  }

}
function findpsw_deal()//找回密码处理
{
$psw=$_POST['psw1'];
$name=$_POST['user_name'];
$u=M('user');
$u->where(array('name'=>$name))->data(array('password'=>md5(md5($psw))))->save();
  echo"<script>alert('密码重置成功!');</script>";
  $this->redirect('User/login_index');
}
function userinfo_index()//==个人信息管理
{
  R('Common/check_login_state');//检测用户登录状态
  $u=M('user');
  $r=$u->where(array('name'=>$_SESSION['user_name']))->find();
  $this->assign('userinfo',$r);//地址信息
  $this->display();
  }
  function userinfo_deal()//==个人信息修改处理
  {
  R('Common/check_login_state');//检测用户登录状态
  $u=M('user');
  $row=$u->where(array('name'=>$_SESSION['user_name']))->find();
  if(md5(md5($_POST['old_psw']))!=$row['password'])
    echo"<script>alert('原密码输入有误');history.go(-1)</script>";
  elseif(!$this->check_email($_POST['email']))
    echo"<script>alert('邮箱地址格式不正确');history.go(-1)</script>";
  else
	  {
  $data=array(
  'email'=>$_POST['email'],
  'receive_name'=>$_POST['rec_name'],
  'tel'=>$_POST['tel'],
  'address'=>$_POST['address'], 
  'youbian'=>$_POST['youbian']
  );
  if($_POST['new_psw']!='')
	  $data['password']=md5(md5($_POST['new_psw']));
  $u->where(array('name'=>$_SESSION['user_name']))->data($data)->save();
  echo"<script>alert('保存成功')</script>";
  $this->redirect('Index/index');
	  }
}
function register_index()//==注册
{
  $this->display();
}
function register_deal()//==注册处理
{
     $name=$_POST['name'];
	 $psw=$_POST['password'];
	 $email=$_POST['email'];
     $verify=$_POST['verify'];
	 if($_SESSION['verify']!=md5(strtolower($verify)))
	 {
	 echo "<script>alert('验证码不正确');history.go(-1);</script>";
	 }
     elseif(!$this->check_email($email))     
	 {
	 echo "<script>alert('电子邮箱地址格式不正确');history.go(-1);</script>";
	 }
	 else
	 {
	 $user=M('user');
     $row=$user->where(array('name'=>$name))->find();

    if(is_array($row))
	{
	echo"<script>alert('用户名已存在');history.go(-1);</script>";
	}
    else
	{
    $data=array(
	'name'=>$name,
	'password'=>md5(md5($psw)),
	'email'=>$email
	);
	$user->data($data)->add();
	echo"<script>alert('注册成功');</script>";
	$this->redirect('Index/index');
	}

	 }
}
function logout()//退出
{
    R('Common/check_login_state');//检测用户登录状态
	session_destroy();
    echo"<script>alert('退出成功！');</script>";
	$this->redirect('Index/index');  
}
}
