<?php
  class IndexAction extends Action
  {
  function index()//==显示商品列表
  {
    if(isset($_SESSION['user_name']))
		$this->assign('user_name',$_SESSION['user_name']);//当前用户名
	$g=M('goods');
	if(isset($_GET['orderby']))
	{
		switch($_GET['orderby'])
		{
		case 'num':$order='purchases desc';break;
		case 'price':$order='stock_price desc';break;
		case 'time':$order='end_time desc';break;
		}
	}
	else
		$order='end_time desc';

    $list=$g->order($order)->select();

    $this->assign('goods_list',$list);//商品列表
    $this->display();
  }

  function goods_detail()//==商品详情
  {
	$id=$_GET['id'];
	$g=M('goods');
	$r1=$g->where(array('id'=>$id))->find();
	$this->assign('goods_msg',$r1);//商品简介

	$m=M('meal');
	$r2=$m->where(array('goods_id'=>$id))->select();
	$this->assign('meal_list',$r2);//商品价目

    $b=M('business');
    $r3=$b->where(array('id'=>$r1['business_id']))->find();
	$this->assign('business_info',$r3);//商家信息
 
    $this->display();
  }
  function search()//==搜索
  {
	$key=$_GET['kw'];
	$g=M('goods');
    $list=$g->where("title like '%$key%' or rule like '%$key%'")->select();
    $this->assign('goods_list',$list);//商品列表
    $this->display('index');
  }
  }