-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 10 月 30 日 14:50
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 数据库: `wy_shop`
--

-- --------------------------------------------------------

--
-- 表的结构 `wy_business`
--

CREATE TABLE IF NOT EXISTS `wy_business` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) CHARACTER SET utf8 NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `tel` varchar(20) CHARACTER SET utf8 NOT NULL,
  `shop_time` varchar(500) CHARACTER SET utf8 NOT NULL COMMENT '营业时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `wy_business`
--

INSERT INTO `wy_business` (`id`, `name`, `address`, `tel`, `shop_time`) VALUES
(1, '鼎鼎记生蚝馆', '福建省福州市晋安区前横路252号中辉新苑1楼', '0591-88005157', ' 17:00—次日02:00'),
(2, '鑫源阁', '福建省福州市鼓楼区三坊七巷澳门路玉山涧3-4号', '0591-88562899', '11:00-22:00');

-- --------------------------------------------------------

--
-- 表的结构 `wy_goods`
--

CREATE TABLE IF NOT EXISTS `wy_goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `original_price` double NOT NULL COMMENT '原价',
  `stock_price` double NOT NULL COMMENT '团购价',
  `purchases` int(10) NOT NULL COMMENT '已购买量',
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `rule` text CHARACTER SET utf8 NOT NULL COMMENT '规则说明',
  `img_address` varchar(100) CHARACTER SET utf8 NOT NULL,
  `business_id` int(10) NOT NULL COMMENT '所属商家id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- 转存表中的数据 `wy_goods`
--

INSERT INTO `wy_goods` (`id`, `title`, `original_price`, `stock_price`, `purchases`, `start_time`, `end_time`, `rule`, `img_address`, `business_id`) VALUES
(2, '298元鑫源阁四人套餐', 433, 298, 12, '2013-10-29 17:04:41', '2014-01-08 17:04:49', '限堂食，不提供餐前外带，餐毕未吃完可免费打包', '2.jpg', 2),
(60, '60元鼎鼎记生蚝馆烤鱼秒杀', 118, 60, 641, '2013-10-12 17:00:09', '2013-12-31 17:00:15', '【五里亭】仅60元，享价值118元『鼎鼎记生蚝馆烤鱼』60元秒杀！2人以上方可使用！赶紧下单了，购买前请先致电商家咨询！', '1.jpg', 1);

-- --------------------------------------------------------

--
-- 表的结构 `wy_meal`
--

CREATE TABLE IF NOT EXISTS `wy_meal` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `unit_price` double NOT NULL,
  `num` double NOT NULL,
  `goods_id` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `wy_meal`
--

INSERT INTO `wy_meal` (`id`, `name`, `unit_price`, `num`, `goods_id`) VALUES
(1, '香辣烤鱼', 38, 1, 1),
(2, '麻辣豆腐', 58, 1, 1),
(3, '王老吉', 22, 4, 1),
(4, '黑椒牛仔骨', 79, 1, 2),
(5, '泡椒田鸡', 69, 1, 2),
(6, '松子黄瓜鱼', 150, 1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `wy_order`
--

CREATE TABLE IF NOT EXISTS `wy_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '也是订单号',
  `user_name` varchar(100) NOT NULL,
  `goods_id` int(10) NOT NULL,
  `time` datetime NOT NULL,
  `num` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `wy_order`
--

INSERT INTO `wy_order` (`id`, `user_name`, `goods_id`, `time`, `num`) VALUES
(4, 'otion', 2, '2013-10-30 17:44:43', 1),
(9, 'otion', 60, '2013-10-30 21:16:25', 7),
(10, 'otion', 2, '2013-10-30 21:32:50', 1),
(11, 'otion', 2, '2013-10-30 22:38:29', 4),
(12, 'otion', 2, '2013-10-30 22:38:58', 1);

-- --------------------------------------------------------

--
-- 表的结构 `wy_user`
--

CREATE TABLE IF NOT EXISTS `wy_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `receive_name` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '收件人姓名',
  `address` varchar(500) CHARACTER SET utf8 NOT NULL,
  `tel` varchar(20) CHARACTER SET utf8 NOT NULL,
  `youbian` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT '邮编',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `wy_user`
--

INSERT INTO `wy_user` (`id`, `name`, `password`, `email`, `receive_name`, `address`, `tel`, `youbian`) VALUES
(1, 'otion', '0ee93166ee300e794a52c8c476e1b0be', '1973718688@qq.com', '汪兆光', '福建省福州大学新区学生公寓30#楼', '18649805971', '350700'),
(2, 'otions', 'd7afde3e7059cd0a0fe09eec4b0008cd', '1973718688@qq.com', '', '', '', '');
