<?php
header("Content-type:text/html;charset='utf8'");

if(version_compare(PHP_VERSION,'5.3.0','<'))
  die('运行本框架需要您的php版本至少为5.3.0,请先升级');

if(!defined('otion_path'))
{
 define('otion_path','./'.basename(dirname(__FILE__)));//定义框架路径
}

if(!defined('app_path'))
{
 define('app_path','./');//定义项目路径
}

//=============初始化时自动创建文件目录和文件=============

 function createFolder($path)//创建文件目录
 {
     if(!is_dir($path))
	 {
     createFolder(dirname($path));
	 mkdir($path,0777);
     }
 }
createFolder(app_path."/Lib/Action");
createFolder(app_path."/Lib/Model");
createFolder(app_path."/Conf");
createFolder(app_path."/Common");
createFolder(app_path."/Data");
createFolder(app_path."/Tpl");
createFolder(app_path."/Runtime/Log");
createFolder(app_path."/Runtime/TplCompiled");
createFolder(app_path."/Runtime/StaticWebPage");


 function createFile($fileName,$content)//创建文件
 {
  if(!file_exists($fileName))
  {
	$file=fopen($fileName,'wb');
	fwrite($file,$content);
	fclose($file);
  }
 }
$dome_file=app_path."/Conf/AppConfig.class.php"; //AppConfig.class.php文件
$content="<?php
class AppConfig
{
 public function index()
 {
 return array(
 //配置项
 'db_type'=>'mysql',
          // 数据库类型（可选项是'mysql','sqlite'）
 'db_connect_way'=>'mysql',
          //连接数据库的方式（可选项是'mysql','sqlite','pdo','adodb'）
//'sqlite_db_path'=>,
         //SQLite数据库文件相对于主入口文件的路径(前提是设置了'db_type'项的值为'sqlite'且开启了php的sqlite扩展)




'db_host'=>'localhost',// 服务器地址
'db_name'=>'', // 数据库名
'db_user'=>'root',// 用户名
'db_psw'=>'',// 密码
//'db_port'=>,//端口号
'db_charset'=>'utf8',//数据库字符集编码
'db_prefix'=>'',// 数据库表前缀（若留空表示不使用表前缀）
//'db_fetch_type'=>,
         //返回数据库查询结果的形式（'assoc'表示只以关联数组形式返回，'num'表示只以索引数组形式返回，'both'表示同时以关联数组和索引数组的形式返回）

//'__PUBLIC__'=>,//当前项目的公共目录
//'__CSS__'=>,//当前项目的公共目录下的css文件夹
//'__JS__'=>,//当前项目的公共目录下的js文件夹
//'__IMAGE__'=>,//当前项目的公共目录的image文件夹

//'__ROOT__'=>,//当前项目的路径
//'__APP__'=>,//当前应用的路径
//'__URL__'=>,//当前模块的路径
//'__SELF__'=>,//当前模块的路径
//'__ACTION__'=>,//当前方法的路径


//'tpl_path'=>,//模板文件存放路径
//'com_path'=>,//模板编译后文件存放路径
//'tmpl_l_delim'=>,//模板文件的左定界符
//'tmpl_r_delim'=>,//模板文件的右定界符
//'tmpl_suffix'=>,//默认的模板文件后缀名
//'theme_list'=>,//模板主题列表
//'default_theme'=>,//默认的模板主题

//'open_staticwp'=>,//是否启用页面静态化
//'staticwp_path'=>,//静态页面文件存放路径
//'staticwp_save_time'=>,//静态页面自动更新周期
//'staticwp_pages'=>,//需要进行静态化处理的页面


//'open_cache'=>,//是否开启memcache缓存
//'memcache_host'=>,//memcache缓存的主机地址
//'memcache_port'=>,//memcache缓存的端口号
//'cache_encrypt'=>,//是否对memcache缓存内容进行加密
//'cache_save_time'=>,//memcache缓存生存时间
//'save_session_in_cache'=>,//是否将session值写入memcache缓存

//'open_rewrite'=>,//是否启用url重写
//'import_doc_hidden'=>,//是否通过url重写隐藏主入口文件名
//'url_suffix'=>,//使用伪静态时允许的url后缀名
//'anti_hotlinking'=>,//需要作防盗链处理的文件夹

//'log_record'=>,//是否开启日志记录功能
//'log_path'=>,//日志文件存放路径
//'log_level'=>,//日志记录级别
//'log_OtionException'=>,//是否在抛出框架定义的OtionException异常对象时将异常信息记入日志

//'crypt_key'=>,//使用Common类提供的encrypt和decrypt加密解密时的秘钥
//'display_OtionException'=>,//是否显示异常信息（默认开启，项目正式发布后可以关闭）
//'display_errors'=>,//是否显示错误信息（默认开启，项目正式发布后可以关闭）
//'url_param_separtor'=>,//url中参数的分隔符
//'check_get_post_sql'=>,//是否自动对所有的get值和post值作防sql注入处理
//'token_open'=>,//是否开启表单令牌验证
 );

 }
}

";
createFile($dome_file,$content);


$dome_file=app_path."/Lib/Action/IndexAction.class.php";//IndexAction.class.php文件

$content="<?php
  class IndexAction extends Action
  {
    function index()
    {
    echo '您好，欢迎使用otionPHP!';
    }
  }
";
createFile($dome_file,$content);


 //============是否显示错误信息========
 $conf=Config::getInstance();
 $display_errors=$conf->get_attribute('display_errors');
 if(!$display_errors)
  ini_set('display_errors',0);
//=============使用自定义异常类OtionException
 new OtionException;

 //============日志记录========
$log_record=$conf->get_attribute('log_record');//是否开启日志记录功能
if($log_record)
{
$log_path=$conf->get_attribute('log_path');//日志文件存放路径
$log_level=$conf->get_attribute('log_level');//日志记录级别
if(in_array('E_ALL',$log_level['open']))//若要记录全部错误
   {
   $error_reporting='E_ALL';
   if(isset($log_level['close'])&&count($log_level['close'])>0)
	   {
       foreach($log_level['close'] as $close_item)
	      $error_reporting.='&~('.$close_item.')';
		   
       }
   }
 else
  {
  $error_reporting='';
  foreach($log_level['open'] as $open_item)
      $error_reporting.='&'.$open_item;
	  
  $error_reporting=ltrim($error_reporting,'&');//去除首部的字符'$'
  }
date_default_timezone_set('Asia/Shanghai');
$t=date('Y-m-d');
$log_path.='/'.$t;

createFolder($log_path);//检查文件夹是否存在,无则创建之

$log_file=$log_path.'/'.$t.'_error.log';
ini_set("log_errors",1); //记录错误信息(保存到日志文件中)
ini_set("error_reporting",$error_reporting); //指定要捕获的错误信息类型
ini_set("error_log",$log_file); //设置日志文件路径（相对于当前脚本文件）及名称
}
function OtionException_deal($msg)//异常信息处理
{
 $conf=Config::getInstance();
 $display_OtionException=$conf->get_attribute('display_OtionException');//是否要显示异常信息
 $log_OtionException=$conf->get_attribute('log_OtionException');//是否将异常信息记入日志

 if($log_OtionException)//若要将异常信息记入日志
	{
    $log_path=$conf->get_attribute('log_path');//日志文件存放路径
    date_default_timezone_set('Asia/Shanghai');
	$t=date('Y-m-d');
	$log_path.='/'.$t;
    createFolder($log_path);//检查文件夹是否存在,无则创建之

    $log_file=$log_path.'/'.$t.'_OtionException.log';
	$f=fopen($log_file,'ab');//写入方式打开，指针指向文件尾，即续写
	$message=str_replace('<br>',"\r\n",$msg);
    fwrite($f,$message);
	fclose($f);
    }
	
	if($display_OtionException)//若要显示异常信息
      return $msg;
    else
      return '';
}

//==================自动加载类=============
function require_file($class_name)//根据类名包含对应文件
 {
if(isset($GLOBALS['app_path']))
	$app_path='./'.$GLOBALS['app_path'];
else
	$app_path=app_path;

if(substr($class_name,-6)=='Action'&&$class_name!='editorAction')
	 {
	 if($class_name=='Action')
     $file=otion_path.'/Lib/Controller/'.$class_name.'.class.php';
	 else
     $file=$app_path.'/Lib/Action/'.$class_name.'.class.php';
	 }
 elseif(substr($class_name,0,5)=='Model')
	 {
     $file=otion_path.'/Lib/Model/'.$class_name.'.class.php';
	 }
 elseif(substr($class_name,0,2)=='DB')
	 {
     $file=otion_path.'/Lib/Model/ModelFactory.class.php';
     }
 elseif(substr($class_name,-5)=='Model')
	 {
     $file=$app_path.'/Lib/Model/'.$class_name.'.class.php';		
	 }
 elseif(substr($class_name,-6)=='Config')
	 {
	 if($class_name=='Config')
	 $file=otion_path.'/Conf/'.$class_name.'.class.php';
	 else
	 $file=$app_path.'/Conf/'.$class_name.'.class.php';
	 }
 elseif(substr($class_name,0,6)=='Common'||$class_name=='OtionException')
	 {
	 $file=otion_path.'/Common/'.$class_name.'.class.php';
	 }
 elseif(substr($class_name,-6)=='Common')
	 {
	 $file=$app_path.'/Common/'.$class_name.'.class.php';
	 }
elseif($class_name=='Tpl_engine')
	 $file=otion_path.'/Lib/View/'.$class_name.'.class.php';
else
	 $file=otion_path.'/Extend/'.$class_name.'.class.php';

if(file_exists($file))
	require($file);

try
 {
	if(!class_exists($class_name))
	 {
		$file=$app_path.'/Lib/Action/EmptyAction.class.php';
		if(file_exists($file))//若定义了空模块
		return 'should use EmptyAction';//通知调用方需要使用空模块
		else
		throw new OtionException('使用了未定义的类'.$class_name.'!');
	 }
 }
catch(OtionException $e)
 {
 echo OtionException_deal($e->getMsg());
 }
}

 function __autoload($class_name)//自动加载类
 {
 require_file($class_name);//根据类名包含对应文件
 }

try
 {
//=============定义系统常量=============

 $conf_arr=$conf->system_constant();

 foreach($conf_arr as $key=>$value)
   define($key,$value);

//=============使用缓存存储_SESSION值

if($conf->get_attribute('open_cache')&&$conf->get_attribute('save_session_in_cache'))
{//若开启了缓存且要将session值写入缓存
   CommonMemcacheSession::start();
} 
//注意：如果在CommonMemcacheSession::start();之前使用session_start();开启session,_SESSION值就不会被纳入缓存而是仍存在服务器文件中
@session_start();
 //============使用表单令牌验证功能
 $token_open=$conf->get_attribute('token_open');
 if($token_open==true)
 {
   if(isset($_POST['otionPHP_token']))
   {
     if(!isset($_SESSION['otionPHP_token'])||$_SESSION['otionPHP_token']==$_POST['otionPHP_token'])
	 {
       throw new OtionException('表单来源非法!');
	 }
   }

 }



 //===url重写处理====
$open_rewrite=$conf->get_attribute('open_rewrite');//是否启用url重写
$hidden=$conf->get_attribute('import_doc_hidden');//是否通过url重写隐藏主入口文件名
$url_suffix=$conf->get_attribute('url_suffix');//使用伪静态时允许的url后缀名
$anti_hotlinking=$conf->get_attribute('anti_hotlinking');//需要作防盗链处理的文件夹

$file=dirname(app_path)."/.htaccess";//AppCommon.class.php文件

if($open_rewrite)//若启用url重写
{
//防盗链处理
  if(count($anti_hotlinking)>0)
   foreach($anti_hotlinking as $anti_item)
   {
	if($anti_item!='*')
	   {
   $content='<IfModule mod_rewrite.c>
RewriteEngine on
RewriteCond %{HTTP_REFERER} !'.$_SERVER['SERVER_NAME'].'
RewriteRule .* -[F]
</IfModule>
';
   $anti_file=dirname(app_path).'/'.$anti_item.'/.htaccess';
   $f=fopen($anti_file,'wb');
   fwrite($f,$content);
   fclose($f);  
	   }
   }
  


if(!file_exists($file))//若修改了配置项import_doc_hidden或url_suffix
	{
//使用伪静态时允许的url后缀名
$suffixs='';
foreach($url_suffix as $item)
 {
	if(!isset($s))
		$s=$item;
	else
		$s.='|'.$item;
 }

$content='<IfModule mod_rewrite.c>
RewriteEngine on
RewriteRule ^(.*).('.$s.')$ $1 [QSA,PT,L]
';

//防盗链处理
  if(count($anti_hotlinking)>0)
   foreach($anti_hotlinking as $anti_item)
   {
	if($anti_item=='*')
     {
	  $content.='
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !'.$_SERVER['SERVER_NAME'].'
RewriteRule .* -[F]
';
	 }
   }


//是否通过url重写隐藏主入口文件名
  if($hidden)
  {
$content.="
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^(.*)$ index.php/$1 [QSA,PT,L]
";
  }
$content.="\r\n</IfModule>";


$f=fopen($file,'wb');
fwrite($f,$content);
fclose($f);
	}
}
else//若未启用url重写
 {
if(file_exists($file))
  unlink($file);
 }


//识别get方式传递的参数
       
if(!isset($_GET['m'])&&!isset($_GET['a']))//不是普通模式的url
{
 $separtor=$conf->get_attribute('url_param_separtor');

 $arr=explode('/',$_SERVER["PHP_SELF"]);
 $n1=count($arr);
 for($i=0;$i<$n1;$i++)
 {
      if(substr_count($arr[$i],'.php'))
	  {
	      if(isset($arr[$i+3]))
		  {
		   if($separtor!='/')  
			 {
			   $get_arr=explode($separtor,$arr[$i+3]);
			   $n2=count($get_arr);
			   for($j=0;$j<$n2;$j+=2)
	               $_GET[$get_arr[$j]]=$get_arr[$j+1];	 
			 }
			else
	    	 {
			  $arrn=count($arr);
			  for($j=$i+3;$j<$arrn;$j+=2)
                 $_GET[$arr[$j]]=$arr[$j+1];
	    	 }
           
	      }
       break;	
	  }
 } 

}
 //====自动对所有的get值和post值作防sql注入处理
 $check=$conf->get_attribute('check_get_post_sql');
 if($check)
 {
  $orig_GET=$_GET;
  $orig_POST=$_POST;
  foreach($_GET as $k=>$v)
  { 
    $r=Common::getInstance()->check_input($v);

	if($r===false)
		die('$_GET['.$k.']中含有非法字符！');
	else
		$_GET[$k]=$r;
  }
  
  foreach($_POST as $k=>$v)
  { 
    $r=Common::getInstance()->check_input($v);

	if($r===false)
		die('$_POST['.$k.']中含有非法字符！');
	else
		$_POST[$k]=$r;
  }
  $_GET['orig']=$orig_GET;//便于在配置文件中令此配置项为true后想获取某个未被过滤的get值
  $_POST['orig']=$orig_POST;//便于在配置文件中令此配置项为true后想获取某个未被过滤的post值
 }

 //===确定模块名和方法名====
 $com=Common::getInstance();
 $class=$com->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);
 $func=$com->getFuncName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);
 $class.='Action';

 $r=require_file($class);
 if($r=='should use EmptyAction')//若使用了空模块
   $class='EmptyAction';


 $model=new $class;
 
 
 if(!method_exists($class,$func))
	 {
	 if(method_exists($class,'_empty'))//若定义了空操作
		 $func='_empty';
	 else
          throw new OtionException('使用了未定义的方法'.$func.'!');
	 }



//===页面静态化处理========
$swp=$conf->get_attribute('staticwp_pages');//需要静态化的页面

$url=Config::getInstance()->get_protocol().'://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];//当前页面url


 foreach($_POST as $pk=>$pv)//同时根据get传值和post传值的不同生成不同静态页面
	 {
	 if(isset($_POST[$pk]))
        $url.='&&'.$pk.'='.$pv;
	 }

$need=0;//$need记录是否被指定要静态化

foreach($swp as $value)
 {
 if(is_array($value))//若有额外指定对应静态化页面的更新周期
	 {  
	     $ff1=$value[0]==__APP__.'/Index/index'||$value[0]==__APP__.'/Index';
	     $ff2=strpos(__APP__,$url)===0&&$ff1; //考虑第一次进入首页时应用入口文件、模块名、方法名的缺省值分别为                                         index.php,Index,index的特殊情况

	if(strpos($url,$value[0])===0||$ff2)//若$value出现在$url的开头位置,或$ff2成立,则当前页面被指定了要静态化
		 {
		     $need=1; //考虑第一次进入首页时应用入口文件、模块名、方法名的缺省值分别为index.php,Index,index的特            殊情况
	         $staticwp_save_time=$value[1];//记录额外指定的自动更新周期
		 }
	 }
	 else
	 {
	 $ff1=in_array(__APP__.'/Index/index',$swp)||in_array(__APP__.'/Index',$swp);
	 $ff2=strpos(__APP__,$url)===0&&$ff1; //考虑第一次进入首页时应用入口文件、模块名、方法名的缺省值分别为                                            index.php,Index,index的特殊情况

     if(strpos($url,$value)===0||$ff2)//若$value出现在$url的开头位置,或$ff2成立,则当前页面被指定了要静态化
    	 $need=1;
	 }
 }


if($conf->get_attribute('open_staticwp')&&$need)//若启用页面静态化且当前页面被指定了要静态化
{
 $path=$conf->get_attribute('staticwp_path');
 createFolder($path);//检查文件夹是否存在,无则创建之
 date_default_timezone_set('Asia/Shanghai');
 $path.='/'.date('Y-m-d').'/'.$class.'/'.$func;
 
 $su=Common::getInstance()->filename_deal($url);//去除不允许出现在文件名中的字符

 $staticwp_file=$path.'/'.$su.'.html';//当前页面url（含get参数）对应静态文件的存放路径

 $flush1=!file_exists($staticwp_file);//$flush1记录该静态文件是否存在
 
 if(!isset($staticwp_save_time))
    $staticwp_save_time=$conf->get_attribute('staticwp_save_time');//若未额外指定，取默认的静态文件自动更新周期

 if(!$flush1)
   {
	if($staticwp_save_time===0)//若额外指定为永久缓存
		$staticwp_save_time=time();
    $flush2=filemtime($staticwp_file)+$staticwp_save_time<time();//$flush2记录该静态文件是否已过期
   }

 //$flush3记录是否强制更新该静态文件:
 $flush3=0;
 $f_name='flush_'.$url;
 $if1=isset($_SESSION[$f_name])&&$_SESSION[$f_name];
 if($if1)
	 $flush3=1;
 else
 {
 $f_name='flush_'.__APP__.'/Index/index';
 $if2=isset($_SESSION[$f_name])&&$_SESSION[$f_name];//考虑第一次进入首页时应用入口文件、模块名、方法名的缺省值                                                      分别为index.php,Index,index的特殊情况

 if(strpos(__APP__,$url)===0&&$if2)
	 $flush3=1;
 }


 if($flush1||$flush2||$flush3)//若原静态文件不存在或已失效或被强制更新
   {
 if($flush3)
	 $_SESSION[$f_name]=0;

 createFolder($path);//创建文件目录

 ob_start();
 ob_clean();//清空ob缓存
 
 $be_func='_before_'.$func;
 if(method_exists($class,$be_func))//若定义了前置操作
	 $model->$be_func();
 
 $model->$func();

 $af_func='_after_'.$func;
 if(method_exists($class,$af_func))//若定义了后置操作
	 $model->$af_func();
 
 $tpl_con=ob_get_contents();

	$file=fopen($staticwp_file,'wb');
	fwrite($file,$tpl_con);
	fclose($file);
   }
 else//直接调用静态页面进行显示
   {
   include($staticwp_file);
   }
}
else//若未启用页面静态化或当前页面没有被指定要静态化
{
 $be_func='_before_'.$func;
 if(method_exists($class,$be_func))//若定义了前置操作
	 $model->$be_func();
 
 $model->$func();

 $af_func='_after_'.$func;
 if(method_exists($class,$af_func))//若定义了后置操作
	 $model->$af_func();
}
 }
 catch(OtionException $e)//捕获异常
 {
 echo OtionException_deal($e->getMsg());
 }
 catch(PDOException $e)
 {
 echo $e->getMessage();
 }
 catch(Exception $e)
 {
 echo $e->getMessage();
 }
//======M():实例化model基类的简便方法===
function M($tableName='')
{
return  Model::getInstance($tableName);
}
//====D():实例化一个自定义的Model类===
function D($tableName)
{
$file=app_path.'/Lib/Model/'.$tableName.'Model.class.php';	
if(file_exists($file))
	{
$m_name=$tableName.'Model';
$m=new $m_name();
$db_name=isset($m->db_name)?$m->db_name:'';
$db_prefix=isset($m->db_prefix)?$m->db_prefix:'';

$db_host=isset($m->db_host)?$m->db_host:'';
$db_user=isset($m->db_user)?$m->db_user:'';
$db_psw=isset($m->db_psw)?$m->db_psw:'';
$db_charset=isset($m->db_charset)?$m->db_charset:'';

$db_type=isset($m->db_type)?$m->db_type:'';
$db_connect_way=isset($m->db_connect_way)?$m->db_connect_way:'';
$sqlite_db_path=isset($m->sqlite_db_path)?$m->sqlite_db_path:'';

$db_fetch_type=isset($m->db_fetch_type)?$m->db_fetch_type:'';

$m->init($tableName,$db_name,$db_prefix,$db_host,$db_user,$db_psw,$db_charset,$db_type,$db_connect_way,$sqlite_db_path,$db_fetch_type);
return $m;
	}
else
	return M($tableName);
}
//====R():跨模块调用===========
function R($mf,$para='',$get_para='')//参数$mf形如'find'或'User/find',$para为实参,$get_para为get参数数组
{
if(substr_count($mf,'/')==2)//若$mf形如'Admin/User/find',即调用Admin项目的User模块下的find()方法
{
$mf_arr=explode('/',$mf);
$GLOBALS['app_path']=$mf_arr[0];

$m=$mf_arr[1].'Action';
$a=$mf_arr[2];
}
elseif(substr_count($mf,'/')==1)//若$mf形如'User/find',即调用User模块下的find()方法
{
$mf_arr=explode('/',$mf);
$m=$mf_arr[0].'Action';
$a=$mf_arr[1];
}
else//若$mf形如'find',即调用本模块下的find()方法
{
 $com=Common::getInstance();
 $class=$com->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);

 $m=$class.'Action';
 $a=$mf;
}
if($para!='')//若设置了实参
{
  call_user_func_array(array($m,$a),$para);
}
else
{
$c=new $m;
$c->$a();
}
if($get_para!='')//若设置了get参数数组
{
foreach($get_para as $pk=>$pi)
 $_GET[$pk]=$pi;
}


}
//====C():动态读取、设置配置参数====
function C_get($name)//动态读取配置参数
{
$conf=Config::getInstance();
return $conf->get_attribute($name);
}
function C_set($name,$value)//动态设置配置参数
{
$conf=Config::getInstance();
$conf->set_attribute($name,$value);
}
function C()//【使用了函数的伪重载】
{
$para_num=func_num_args();//获取实参的个数
$func=$para_num==1?'C_get':'C_set';//要转去调用的函数名
$para=func_get_args();//获取实参
return call_user_func_array($func,$para);//转去调用指定的函数，并传递实参
}

//====load():动态加载自定义的扩展类文件===
function load($file)
{
$file=otion_path.'/Extend/'.$file;
if(file_exists($file))
	require_once($file);
else
	throw new OtionException("指定的类文件".$file."不存在!");
}
