<?php
//数据库备份
class CommonDatabaseBackup
{
 private $conf;//保存Config对象
 private $model;//保存Model对象

 private $structure;//数据表结构信息
 private $data;//数据表中的数据

private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
     self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {
 }

 private function __construct()
 {
 $this->set_attribute('model',Model::getInstance());
 $this->set_attribute('conf',Config::getInstance());
 
 $this->set_attribute('structure','');
 $this->set_attribute('data','');
 }

 public function get_attribute($name)//读取属性值
 {
 if(isset($this->$name)) 
     return $this->$name;
 else
	throw new OtionException('属性'.$name.'不存在！');
 }
 public function set_attribute($name,$value)//设置属性值
 {
 $this->$name=$value;
 }

 public function index($backup_tables,$backup_filepath,$inter)//备份数据库信息
 {
  $db_name=$this->get_attribute('conf')->get_attribute('db_name');//数据库名

  $db_type=$this->get_attribute('conf')->get_attribute('db_type');//数据库类型
  if($db_type=='sqlite')//如果是sqlite数据库
	 {
  $sqlite_db_path=$this->get_attribute('conf')->get_attribute('sqlite_db_path');//SQLite数据库文件路径
  copy($sqlite_db_path,$file);//复制sqlite数据库文件到备份文件存放路径，并重命名
  Common::getInstance()->compress($file,true);//将数据库文件压缩后存储,并删除压缩前的文件
	 }
  elseif($db_type=='mysql')//如果是mysql数据库
	 {	

    ini_set('max_execution_time', 0);//运行最大时间无限

  
  if(in_array('*',$backup_tables))//若要备份所有数据表
  {
   $arr=$this->get_attribute('model')->query('show tables from '.$db_name,false);

   foreach($arr as $item)
	  {
	 $this->get_struct_msg($item['Tables_in_otionphp']);//获取表结构信息
	 $this->get_data_msg($item['Tables_in_otionphp']);//获取表中数据
	  }
  }
  else
  {
   foreach($backup_tables as $item)
	  {
	 $this->get_struct_msg($item);//获取表结构信息
	 $this->get_data_msg($item);//获取表中数据
	  }
  }
  $content=$this->get_attribute('structure').$this->get_attribute('data');
  
  $this->createFolder($backup_filepath);//检查存放备份文件的文件夹是否存在，无则创建之
  date_default_timezone_set('Asia/Shanghai');
  $file=$backup_filepath.'/'.Common::getInstance()->filename_deal($db_name.'_'.date('Y-m-d_H-i-s').'_'.$inter.'.sql');//备份文件名

  $f=fopen($file,'wb');
  fwrite($f,$content);//写入备份文件
  fclose($f);

  Common::getInstance()->compress($file,true);//将数据库文件压缩后存储,并删除压缩前的文件
	 }

 }
   private function createFolder($path)//创建文件目录
   {
     if(!is_dir($path))
	 {
		 echo'd';
     $this->createFolder(dirname($path));
	 mkdir($path,0777);
     }
  }

 private function get_struct_msg($tableName)//获取表结构信息
 {
	$content=$this->get_attribute('structure');

    $sql = 'show create table '.$tableName;
    $row=$this->get_attribute('model')->query($sql,false);

    $db_fetch_type=$this->get_attribute('conf')->get_attribute('db_fetch_type');
	
	if($db_fetch_type=='num')
    $content.=$row[0][1].";\r\n\r\n";
	else
    $content.=$row[0]['Create Table'].";\r\n\r\n";//获取当前表被创建时的sql语句

	$this->set_attribute('structure',$content);
 }
 private function get_data_msg($tableName)//获取表中数据
 {
	$content=$this->get_attribute('data');  

    $arr=$this->get_attribute('model')->query('select * from '.$tableName,false);
    
	$content.="\r\nINSERT INTO `".$tableName."` VALUES";
    
	$num=0;
	foreach($arr as $row)
	{
	 if(++$num%3==0)//每200条记录配一个INSERT INTO
		{
         $content=rtrim($content,',');//删除最后一个逗号
		 $content.=";\r\nINSERT INTO `".$tableName."` VALUES";
		}

	 $content .= "\r\n(";
     foreach($row as $key => $val)
	 {
      $content.= '"'.mysql_real_escape_string($val).'",';//对其中的' ，"，\，\r，\n，\x00，\x1a进行转义
     }
     $content=rtrim($content,',');//删除最后一个逗号
	 $content.='),';
	}

    $content=rtrim($content,',');
	$content.=";\r\n";
	$this->set_attribute('data',$content);
 }

}
