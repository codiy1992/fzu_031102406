<?php
class CommonMemcacheSession
{
  private static $mem;//保存memcache对象
  private static $save_time;//session值在缓存中的生存时间

 public static function start()
 {
  self::$mem=CommonMemcache::getInstance();
  self::$save_time=ini_get('session.get_maxlifetime');//获取配置文件中session的最大回收时间

  session_set_save_handler
  (
   array(__CLASS__,'open'),
   array(__CLASS__,'close'),
   array(__CLASS__,'read'),
   array(__CLASS__,'write'),
   array(__CLASS__,'destroy'),
   array(__CLASS__,'gc')
  );

 }
   public static function open($path,$name)
   {
   return true;
   }
   public static function close()
   {
   return true;
   }
   public static function gc()
   {
   return true;
   }
   
   private static function AppSessionName($SessionName)//把本应用的路径作为$SessionName的前缀，防止不同项目存在session名时读取了缓存中其他项目的session值
   {
   return __APP__.$SessionName;
   }


   public static function read($SessionName)//读取
   {
    $SessionName=self::AppSessionName($SessionName);

    if(Config::getInstance()->get_attribute('cache_encrypt'))//若有对缓存内容加密
    {
    $r=self::$mem->get(md5($SessionName));
    $r=Common::getInstance()->decrypt($r,Config::getInstance()->get_attribute('crypt_key'));//解密
    }
    else
    $r=self::$mem->get($SessionName);

   
   if(!$r)
	   return '';
   else
   {
   return $r;
   }
  }
   public static function write($SessionName,$value)//写入
   {

   $SessionName=self::AppSessionName($SessionName);

   if(Config::getInstance()->get_attribute('cache_encrypt'))//若要对缓存内容加密
   {
   $value=Common::getInstance()->encrypt($value,Config::getInstance()->get_attribute('crypt_key'));//加密
   self::$mem->set(md5($SessionName),$value,MEMCACHE_COMPRESSED,self::$save_time);
   }
   else
    self::$mem->set($SessionName,$value,MEMCACHE_COMPRESSED,self::$save_time);  
   }
   public static function destroy($SessionName)//销毁
   {
   $SessionName=self::AppSessionName($SessionName);
   self::$mem->delete($SessionName);
   }

}
