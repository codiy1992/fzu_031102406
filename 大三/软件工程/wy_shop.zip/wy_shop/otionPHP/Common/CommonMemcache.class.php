<?php
class CommonMemcache
{
  private static $instance=null;
  public static function getInstance($host='',$port='')
  {
  if(is_null(self::$instance))
	  {
	  $mem=new Memcache;
	  self::$instance=$mem;
	  }

  $conf=Config::getInstance();
  if($host=='')
	  $host=$conf->get_attribute('memcache_host');
  if($port=='')
	  $port=$conf->get_attribute('memcache_port');

  self::$instance->connect($host,$port);

  return self::$instance;//这种情况下不会再自动调用构造函数
  }
  private function __clone(){}
  private function __construct(){}
  public function __destruct()
  {
  self::$instance->close();
  }
}
