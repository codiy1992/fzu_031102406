<?php
class OtionException extends Exception
{
 function getMsg()
 {
  $trace=$this->getTraceAsString();
  $trace=str_replace('#','<br>#',$trace);

  $str='<br><br>发生了异常！<br>异常位置：文件'.$this->getFile().'中的第'.$this->getLine().'行。<br>异常信息：'.$this->getMessage().'<br>异常代码：'.$this->getCode().'<br>追踪路线：'.$trace;
  
  return $str;
 }
}
