<?php
class Common
{
private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
     self::$instance=new self;
  }

  return self::$instance;
}

 private function __clone()  {}
 

 final private function getModelOrActionName($url,$name)//获取当前使用的模块名或方法名(使用了final声明，以防被子类覆写)
 {	

  $arr=explode('?',$url);
  if(count($arr)==2&&substr_count($arr[1],'m=')==1&&substr_count($arr[1],'&a=')==1)//若是按get方式确定使用的模块和方法
  {
  $model=isset($_GET['m'])?$_GET['m']:'Index';
  $action=isset($_GET['a'])?$_GET['a']:'index';
  }
  else//若是按斜杠分隔方式确定使用的模块和方法
  {
   $arr=explode('/',$arr[0]);
   $arrn=count($arr);
   for($i=0;$i<$arrn;$i++)
   {
   if(substr_count($arr[$i],'.php'))
	  {
      $model=isset($arr[$i+1])?$arr[$i+1]:'Index';
      $action=isset($arr[$i+2])?$arr[$i+2]:'index';
	  
	  break;
      }
   }

  }
  if($name=='model')
  return $model;
  elseif($name=='action')
  return $action;
 }
 //=====获取当前使用的模块名=======
 final public function getModelName($url)
 {
 return $this->getModelOrActionName($url,'model'); 
 }
//=====获取当前使用的方法名=======
 final public function getFuncName($url)
 {
 return $this->getModelOrActionName($url,'action'); 
 }
//=======提示信息====

 final public function show_tip($url,$msg='',$refresh_time='0')
 {
 
 $m=$this->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的模块名称
 $a=$this->getFuncName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的方法名称
 
 $arr=explode('/',$url);
 if(!isset($arr[1]))//若形参形如"index"或"index?id=3"
  $url=__URL__.'/'.$url;	
 else//若形参形如"Index/index"或"Index/index?id=3"
   $url=__APP__.'/'.$arr[0].'/'.$arr[1];

 $content="
        <html>
		<head>
		        <meta charset='utf-8'>
				<meta http-equiv='refresh' content='".$refresh_time."; url=".$url."'/>
				<title>提示信息</title>
                <script>
                var num=".$refresh_time.";
                function timer() 
                { 
                 document.getElementById('timer').innerHTML =num+'秒钟后自动跳转...';
				 num--;
                 if(num>=0)
                     setTimeout('timer()',1000); 
                 }
				 </script>
		</head>
				<body onload='timer()'>
                ".$msg."<br><br>";
				

	if($refresh_time>0)
		$content.="<div id = 'timer'></div><br><a href=".$url.">若页面没有正常跳转，请点击这里</a>";

    $content.="</body></html>";
    echo $content;
 }
//===========URL重定向======
 final public function redirect($url)                     
 {
 $this->show_tip($url,'',0);
 }
//======验证email地址格式是否正确======
 public function check_email($email)                     
 {
 if(preg_match('/^\w+@\w+\.+\w{2,3}$/',$email))
    return true;
 else
	 return false;
 }
//======防sql注入攻击========
 public function check_input($sql_str)
 {
     $r=preg_match('/select|insert|update|delete|\/\*|;|\*|\.\.\/|\.\/|union|or|and|into|load_file|outfile/i',$sql_str);     // 匹配时不区分大小写，含有设定的危险字符时过滤并返回1给$r，否则返回0给$r
     if(!$r)  //不含以上设定的危险字符
	 {  
        $sql_str=htmlspecialchars($sql_str);//把一些预定义的字符转换为HTML实体

		if (!get_magic_quotes_gpc())//取得php.ini中magic_quotes_gpc的值(0即关闭,1即开启)
		 {
    	  $sql_str=addslashes($sql_str);
		 }

	$sql_str=str_replace("%","\%",$sql_str);//转义掉"%"
	$sql_str=str_replace("_","\_",$sql_str);//转义掉"_"
	//以上两个str_replace替换转义目的是防止黑客转换SQL编码进行攻击
    
	return $sql_str;
	 }
    else                //含有设定的危险字符
	{
	return false;
	}
/*注释：
 htmlspecialchars()函数把一些预定义的字符转换为HTML实体,具体有：&(和号)变成&amp;"(双引号)变成&quot;'(单引号)    变成&#039;<(小于)变成&lt;>(大于)变成&gt;
 get_magic_quotes_gpc()函数和addslashes()函数作用都是在$rsql_str中出现的单引号 (')，双引号 (")，反斜杠 (\)，NULL前添加反斜杠
*/

 }
//========加密函数（明文，秘钥，是否启用Base64）======
   public function encrypt($content,$key,$toBase64=true)
	{

		$content=serialize($content);//序列化

        $r = md5($key);
        $c=0;
        $v = "";
		$len = strlen($content);
		$l = strlen($r);
        for ($i=0;$i<$len;$i++)
		{
         if ($c== $l) $c=0;
         $v.= substr($r,$c,1) .
             (substr($content,$i,1) ^ substr($r,$c,1));
         $c++;
        }
        if($toBase64)
		{
            return base64_encode(self::ed($v,$key));
        }
		else
		{
            return self::ed($v,$key);
        }

    }
//=====解密函数（密文，秘钥，是否启用Base64)=======
    public function decrypt($content,$key,$toBase64=true)
	{
        if($toBase64)
		{
            $content = self::ed(base64_decode($content),$key);
        }
		else
		{
            $content = self::ed($content,$key);
        }
        $v = "";
		$len = strlen($content);
        for ($i=0;$i<$len;$i++)
		{
         $md5 = substr($content,$i,1);
         $i++;
         $v.= (substr($content,$i,1) ^ $md5);
        }
		$v=unserialize($v);//反序列化
        return $v;
    }


   public function ed($content,$key)//在加密解密中用到
   {
      $r = md5($key);
      $c=0;
      $v = "";
	  $len = strlen($content);
	  $l = strlen($r);
      for ($i=0;$i<$len;$i++)
	  {
         if ($c==$l) $c=0;
         $v.= substr($content,$i,1) ^ substr($r,$c,1);
         $c++;
      }
      return $v;
   }


 //=======处理文件名使符合文件命名规则=====
 public function filename_deal($filename,$replace_char='_')//(第二个字符参数用于替代不允许出现在文件名中的字符)
 {
  $filename=preg_replace('/\:|\/|\\\|\?|\*|\"|<|>|\|/',$replace_char,$filename);//去除不允许作为文件名的字符
  return $filename;
 }
//=====删除文件夹======
public function delete_dir($dir)
{
   $dh = opendir($dir);
   while ($file = readdir($dh))
   {
      if ($file != "." && $file != "..")
      {
         $fullpath = $dir . "/" . $file;
         if (!is_dir($fullpath))
            unlink($fullpath);
         else
            $this->delete_dir($fullpath);
      }
   }
   closedir($dh);
   if (rmdir($dir))
      return true;
   else
      return false;
   
}
//======压缩==========
public function Compress($file,$delete=false,$save_path='')
{
$file=iconv('UTF-8','GBK',$file);

if($save_path==='')//若未指定
	$save_path=dirname($file);

$file=ltrim($file,'./');//去除首部的符号.和/
$save_path=ltrim($save_path,'./');

date_default_timezone_set('Asia/Shanghai');
$time=date('YmdHis');
$zipname=basename($file).$time.'.zip';//压缩形成的文件名

$zip=new ZipArchive();
$zip->open($zipname,ZipArchive::OVERWRITE);//创建一个空的zip文件

if(is_dir($file))//如果要压缩的是一个文件夹
  {
 $this->compress_dir($file,$save_path,$zip,$zipname);
 $zip->close();
  }
elseif(is_file($file))
  {
$file_here=$time.basename($file);
copy($file,$file_here);//把待压缩文件复制一份到本目录下

$zip->addFile($file_here);//相对于当前目录的路径
$zip->close();
unlink($file_here);//要先关闭$zip->close()后才生成压缩文件，即关闭后才能删除被压缩的文件
  }

rename($zipname,$save_path.'/'.$zipname);//移动压缩后文件到指定存放路径

if($delete)//若要删除压缩前的文件
{
    if(is_dir($file))//若是文件夹
     $this->delete_dir($file);
	elseif(is_file($file))//若是文件
	 unlink($file);
}	
}
//====压缩文件夹====
public function compress_dir($path,$save_path,$zip,$zipname)
{
$handler = opendir($path); //打开当前文件夹由$path指定。
/*
循环的读取文件夹下的所有文件和文件夹
其中$filename = readdir($handler)是每次循环的时候将读取的文件名赋值给$filename，
为了不陷于死循环，所以还要让$filename !== false。
一定要用!==，因为如果某个文件名如果叫'0'，或者某些被系统认为是代表false，用!=就会停止循环
*/
 while(($filename=readdir($handler))!==false) 
 {
 if ($filename!="."&&$filename!="..") //文件夹文件名字为'.'和'..'，不要对他们进行操作
  {
 if(is_dir($path."/".$filename)) // 如果读取的某个对象是文件夹，则递归
  $this->compress_dir($path."/".$filename,$save_path,$zip,$zipname);
 else//将文件加入zip对象 
  $zip->addFile($path."/".$filename);
  }
 }
 closedir($handler);
}


//=========解压缩========
 public function decompress($file,$delete=false,$to='')
 {

	 if($to==='')//若未指定
		 $to=dirname($file);

	 $file=ltrim($file,'./');//去除首部的符号.和/
	 $to=ltrim($to,'./');

     $dir=getcwd();//获取当前绝对路径
     $file_path=$dir.'/'.iconv('UTF-8','GBK',$file);//要被解压的文件绝对路径（及文件名）
	
     $zip = new ZipArchive() ;
     if ($zip->open($file_path) !== true) 
            throw new OtionException('不能打开压缩文件'.$file_path);

     $zip->extractTo($to); //使用ZipArchive()解压：
     $zip->close(); 
     
	 if($delete)
	 unlink($file_path);//删除解压前的原文件
 }
//=========获得当前使用的浏览器名称============
function browser_name()
{
    $agent       = $_SERVER['HTTP_USER_AGENT'];
    $browser     = '';
    $browser_ver = '';

    if (preg_match('/MSIE\s([^\s|;]+)/i', $agent, $regs))
    {
        $browser     = 'Internet Explorer';
        $browser_ver = $regs[1];
    }
    elseif (preg_match('/FireFox\/([^\s]+)/i', $agent, $regs))
    {
        $browser     = 'FireFox';
        $browser_ver = $regs[1];
    }
    elseif (preg_match('/Maxthon/i', $agent, $regs))
    {
        $browser     = '(Internet Explorer ' .$browser_ver. ') Maxthon';
        $browser_ver = '';
    }
    elseif (preg_match('/Opera[\s|\/]([^\s]+)/i', $agent, $regs))
    {
        $browser     = 'Opera';
        $browser_ver = $regs[1];
    }
    elseif (preg_match('/OmniWeb\/(v*)([^\s|;]+)/i', $agent, $regs))
    {
        $browser     = 'OmniWeb';
        $browser_ver = $regs[2];
    }
    elseif (preg_match('/Netscape([\d]*)\/([^\s]+)/i', $agent, $regs))
    {
        $browser     = 'Netscape';
        $browser_ver = $regs[2];
    }
    elseif (preg_match('/safari\/([^\s]+)/i', $agent, $regs))
    {
        $browser     = 'Safari';
        $browser_ver = $regs[1];
    }
    elseif (preg_match('/NetCaptor\s([^\s|;]+)/i', $agent, $regs))
    {
        $browser     = '(Internet Explorer ' .$browser_ver. ') NetCaptor';
        $browser_ver = $regs[1];
    }
    elseif (preg_match('/Lynx\/([^\s]+)/i', $agent, $regs))
    {
        $browser     = 'Lynx';
        $browser_ver = $regs[1];
    }

    if (!empty($browser))
    {
       $brower_type=addslashes($browser . ' ' . $browser_ver);
    }
return $brower_type;
}
}
