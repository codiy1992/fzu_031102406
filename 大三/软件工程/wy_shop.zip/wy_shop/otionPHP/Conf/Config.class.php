<?php
class Config
{
private $db_type;
          // 数据库类型（可选项是'mysql','sqlite'）
private $db_connect_way;
          //连接数据库的方式（可选项是'mysql','sqlite','pdo'）
private $sqlite_db_path;
         //SQLite数据库文件相对于主入口文件的路径(前提是设置了'db_type'项的值为'sqlite'且开启了php的sqlite扩展)



private $db_host;// 服务器地址
private $db_name; // 数据库名
private $db_user;// 用户名
private $db_psw;// 密码
private $db_port;//端口号
private $db_charset;//数据库字符集编码
private	$db_prefix;// 数据库表前缀（若留空表示不使用表前缀）
private $db_fetch_type;
         //返回数据库查询结果的形式（'assoc'表示只以关联数组形式返回，'num'表示只以索引数组形式返回，'both'表示同时以关联数组和索引数组的形式返回）

private $__PUBLIC__;//当前项目的公共目录
private $__CSS__;//当前项目的公共目录下的css文件夹
private $__JS__;//当前项目的公共目录下的js文件夹
private $__IMAGE__;//当前项目的公共目录的image文件夹

private $__ROOT__;//当前项目的路径
private $__APP__;//当前应用的路径
private $__URL__;//当前模块的路径
private $__SELF__;//当前模块的路径
private $__ACTION__;//当前方法的路径


private $tpl_path;//模板文件存放路径
private $com_path;//模板编译后文件存放路径
private $tmpl_l_delim;//模板文件的左定界符
private $tmpl_r_delim;//模板文件的右定界符
private $tmpl_suffix;//默认的模板文件后缀名
private $theme_list;//模板主题列表
private $default_theme;//默认的模板主题

private $open_staticwp;//是否启用页面静态化
private $staticwp_path;//静态页面文件存放路径
private $staticwp_save_time;//静态页面自动更新周期
private $staticwp_pages;//需要进行静态化处理的页面


private $open_cache;//是否开启memcache缓存
private $memcache_host;//memcache缓存的主机地址
private $memcache_port;//memcache缓存的端口号
private $cache_encrypt;//是否对memcache缓存内容进行加密
private $cache_save_time;//memcache缓存生存时间
private $save_session_in_cache;//是否将session值写入memcache缓存

private $open_rewrite;//是否启用url重写
private $import_doc_hidden;//是否通过url重写隐藏主入口文件名
private $url_suffix;//使用伪静态时允许的url后缀名
private $anti_hotlinking;//需要作防盗链处理的文件夹

private $log_record;//是否开启日志记录功能
private $log_path;//日志文件存放路径
private $log_level;//日志记录级别
private $log_OtionException;//是否在抛出框架定义的OtionException异常对象时将异常信息记入日志

private $crypt_key;//使用Common类提供的encrypt和decrypt加密解密时的秘钥
private $display_OtionException;//是否显示异常信息（默认开启，项目正式发布后可以关闭）
private $display_errors;//是否显示错误信息（默认开启，项目正式发布后可以关闭）
private $url_param_separtor;//url中参数的分隔符
private $check_get_post_sql;//是否自动对所有的get值和post值作防sql注入处理
private $token_open;//是否开启表单令牌验证

private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
     self::$instance=new self;
  }
  return self::$instance;
}
 private function __clone()
 {
 }
private function __construct()
{
 $this->set_attribute('db_type','mysql'); 
 $this->set_attribute('db_connect_way','mysql');
 $this->set_attribute('sqlite_db_path','');


 $this->set_attribute('db_host','localhost'); 
 $this->set_attribute('db_user','root');      
 $this->set_attribute('db_psw','');    
 $this->set_attribute('db_port','3306');
 $this->set_attribute('db_charset','utf8');
 $this->set_attribute('db_fetch_type','assoc');

 $path_arr=explode('\\',getcwd());//getcwb()返回当前文件所在路径(D:\wamp\www\others\otion_app)
 $arr=explode($path_arr[count($path_arr)-1],$_SERVER['REQUEST_URI']);
                                 //explode('otion_app',/others/otion_app/User/index?id=2)
 $arr[0]=$arr[0]?$arr[0]:'/';

 $this->set_attribute('__ROOT__',$this->get_protocol().'://'.$_SERVER['HTTP_HOST'].$arr[0].$path_arr[count($path_arr)-1]);

 $this->set_attribute('__PUBLIC__',$this->get_attribute('__ROOT__').'/Public');
 $this->set_attribute('__CSS__',$this->get_attribute('__PUBLIC__').'/Css');
 $this->set_attribute('__JS__',$this->get_attribute('__PUBLIC__').'/Js');
 $this->set_attribute('__IMAGE__',$this->get_attribute('__PUBLIC__').'/Image');

 $this->set_attribute('__APP__',$this->get_attribute('__ROOT__').'/'.basename($_SERVER['SCRIPT_NAME']));
 $this->set_attribute('__URL__',$this->get_attribute('__APP__').'/'.Common::getInstance()->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']));
 $this->set_attribute('__SELF__',$this->get_attribute('__URL__'));
 $this->set_attribute('__ACTION__',$this->get_attribute('__URL__').'/'.Common::getInstance()->getFuncName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']));


 $this->set_attribute('tpl_path',app_path.'/Tpl');
 $this->set_attribute('com_path',app_path."/Runtime/TplCompiled");

 $this->set_attribute('tmpl_l_delim','{');
 $this->set_attribute('tmpl_r_delim','}');
 $this->set_attribute('tmpl_suffix','.html');
 $this->set_attribute('theme_list',array());
 $this->set_attribute('default_theme','');

 $this->set_attribute('open_staticwp',true);
 $this->set_attribute('staticwp_path',app_path."/Runtime/StaticWebPage");
 $this->set_attribute('staticwp_save_time',60);
 $this->set_attribute('staticwp_pages',array());
 
 $this->set_attribute('open_cache',false);
 $this->set_attribute('memcache_host','localhost');
 $this->set_attribute('memcache_port',11211);
 $this->set_attribute('cache_encrypt',true);
 $this->set_attribute('cache_save_time',3600);
 $this->set_attribute('save_session_in_cache',false);

 $this->set_attribute('open_rewrite',false);
 $this->set_attribute('import_doc_hidden',false);
 $this->set_attribute('url_suffix',array('.html'));
 $this->set_attribute('anti_hotlinking',array());

 $this->set_attribute('log_record',false);
 $this->set_attribute('log_path',app_path.'/Runtime/Log');
 $this->set_attribute('log_level',array('open'=>array(),'close'=>array()));
 $this->set_attribute('log_OtionException',false);
 
 $this->set_attribute('crypt_key','otionPHP');
 $this->set_attribute('display_OtionException',true);
 $this->set_attribute('display_errors',true);
 $this->set_attribute('url_param_separtor','/');
 $this->set_attribute('check_get_post_sql',true);
 $this->set_attribute('token_open',false);

 //===根据具体应用的config.php内容覆写配置信息===

 $app=new AppConfig;
 $app_conf=$app->index();

 foreach($app_conf as $key=>$value)
	{
	  if($key=='staticwp_pages')//指定要静态化的页面
	  {
		 foreach($value as $k=>$v)
		 {
		  if(is_array($v))
			 {
			 $v[0]=$this->get_attribute('__APP__').'/'.$v[0];
		     $value[$k]=$v;
			 }
		  elseif($v=='*')
		  $value[$k]=$this->get_attribute('__APP__');
		  else
		  $value[$k]=$this->get_attribute('__APP__').'/'.$v;
		 }
	  }
	  elseif($key=='url_param_separtor')//url中参数的分隔符
	  {
           if($value=='?'||$value=='&'||$value=='_')
			  throw new OtionException("配置项'url_param_separtor'不允许设置为'?'或'&'或'_'");
	  }

	$this->set_attribute($key,$value);//覆写
	}

}
public function get_attribute($name)//读取属性值
{
if(isset($this->$name)) 
     return $this->$name;
else
	throw new OtionException('属性'.$name.'不存在！');
}
public function set_attribute($name,$value)//设置属性值
{
$this->$name=$value;
}

final public function system_constant()//返回要定义的系统常量
{
return array
(
	'__PUBLIC__'=>$this->get_attribute('__PUBLIC__'),
	'__CSS__'=>$this->get_attribute('__CSS__'),
	'__JS__'=>$this->get_attribute('__JS__'),
	'__IMAGE__'=>$this->get_attribute('__IMAGE__'),

	'__ROOT__'=>$this->get_attribute('__ROOT__'),
	'__APP__'=>$this->get_attribute('__APP__'),
	'__URL__'=>$this->get_attribute('__URL__'),
	'__SELF__'=>$this->get_attribute('__SELF__'),
	'__ACTION__'=>$this->get_attribute('__ACTION__'),
);

}
 public function get_protocol()//======获取当前协议名======
 {
    $scheme = "http";
    if (isset($_SERVER["REQUEST_SCHEME"]))
	{
        $scheme = $_SERVER["REQUEST_SCHEME"];
    } elseif (isset($_SERVER["HTTPS"]) && $_SERVER['HTTPS'] === 1) //Apache
	{ 
        $scheme = "https";
    } elseif (isset($_SERVER["HTTPS"]) && $_SERVER['HTTPS'] === 'on')//IIS
	{ 
        $scheme = "https";
    } elseif ($_SERVER['SERVER_PORT'] == 443)//其他
	{ 
        $scheme = "https";
    }    
    return $scheme;
 }
}

