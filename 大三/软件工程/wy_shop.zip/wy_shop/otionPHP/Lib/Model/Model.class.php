<?php
//=====================Model类=========================
class Model extends ModelOperate
{
public function getInstance($tableName='')//返回一个自身的实例(Model基类)
{
  $m=new self();
  $m->init($tableName);
  return $m;
}
public function init($tableName,$db_name='',$db_prefix='',$db_host='',$db_user='',$db_psw='',$db_charset='',$db_type='',$db_connect_way='',$sqlite_db_path='',$db_fetch_type='')
{
  $conf=Config::getInstance();
  
  $db_prefix=$db_prefix==''?$conf->get_attribute('db_prefix'):$db_prefix;
  $tableName=$db_prefix?strtolower($db_prefix.$tableName):strtolower($tableName); 
  $this->set_attribute('tableName',$tableName); //保存表名 
  
  if($db_name==''&&$db_host==''&&$db_user==''&&$db_psw==''&&$db_charset==''&&$db_type==''&&$db_connect_way==''&&$sqlite_db_path=='')
  {
    $this->set_attribute('db',ModelFactory::getInstance());//保存数据库操作对象
  }
  else
  {
    if($db_type=='')  
	   $db_type=$conf->get_attribute('db_type');
    if($db_connect_way=='')  
	   $db_connect_way=$conf->get_attribute('db_connect_way');

    $db='DB'.$db_connect_way.'_'.$db_type;
    
	if($db_type!='sqlite')//若不是使用sqlite数据库
      $obj=new $db($db_name,$db_host,$db_user,$db_psw,$db_charset,$db_fetch_type);
	else
	  $obj=new $db($sqlite_db_path,$db_fetch_type);

    $this->set_attribute('db',$obj);
  }
  
  if($conf->get_attribute('open_cache'))
	{
	 $host=$conf->get_attribute('memcache_host');
	 $port=$conf->get_attribute('memcache_port');
     $this->set_attribute('memcache',CommonMemcache::getInstance($host,$port));//若开启了缓存,则保存Memcache缓存对象
	}
}

}


