<?php
//======================选择数据库类型(工厂模式)=============

//=========工厂类
class ModelFactory
{
 private static $instance=null;//保存自身实例(单例模式)
 public static function getInstance()
 {
  if(is_null(self::$instance))
  {
  $conf=Config::getInstance();
  $db=$conf->get_attribute('db_type');//获取配置文件中的数据库类型
  $db_connect_way=$conf->get_attribute('db_connect_way');//获取配置文件中连接数据库的方式
  $db='DB'.$db_connect_way.'_'.$db;
  $obj=$db::getInstance();
  
  if($obj instanceof IDB)
      self::$instance=$obj;
  else
      throw new OtionException('类'.$db.'没有实现IDB接口！');
  }

  return self::$instance;
 }
}

//======数据库操作接口
interface IDB
{
 public function query($str,$get_result_set);//查询(第二个参数表示是否直接返回结果集)
 public function add($str);//添加
 public function delete($str);//删除
 public function update($str);//修改
 public function last_insert_id();//上次插入的最后一条记录的id值
}
//=======使用mysql方式连接mysql数据库
class DBmysql_mysql implements IDB
{
private $link;
private $db_fetch_type;
private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {
 }

 public function __construct($db_name='',$db_host='',$db_user='',$db_psw='',$db_charset='',$db_fetch_type='')
 {
  $conf=Config::getInstance();

  if($db_name=='')  
	  $db_name=$conf->get_attribute('db_name');
  if($db_host=='')  
	  $db_host=$conf->get_attribute('db_host');
  if($db_user=='')  
	  $db_user=$conf->get_attribute('db_user');
  if($db_psw=='')  
	  $db_psw=$conf->get_attribute('db_psw');
  if($db_charset=='')  
	  $db_charset=$conf->get_attribute('db_charset');
  if($db_fetch_type=='')  
	  $db_fetch_type=$conf->get_attribute('db_fetch_type');

  $this->db_fetch_type=$db_fetch_type;//返回数据库查询结果的形式

  $link=mysql_connect($db_host,$db_user,$db_psw);
  if($link===false)
	  throw new OtionException('连接数据库失败！');

  $r=mysql_select_db($db_name,$link);
  if($r===false)
	  throw new OtionException('选择数据库'.$db_name.'失败！');

  $r=mysql_query('set names '.$db_charset);
  if($r===false)
	  throw new OtionException('设置数据库字符集编码'.$db_charset.'失败！');

  $this->link=$link;
 }

 public function query($str,$get_result_set)
 {
 $r=mysql_query($str);

 if($r===false)
	  throw new OtionException('查询记录失败！相应的sql语句为:'.$str);

 
 if($get_result_set===true)//若要求直接返回结果集
	 {
	 return $r;
	 }
 
 $db_fetch_type=$this->db_fetch_type==''?Config::getInstance()->get_attribute('db_fetch_type'):$this->db_fetch_type;
 switch(strtolower($db_fetch_type))
 {
 case 'assoc':$type=MYSQL_ASSOC;break;
 case 'num':$type=MYSQL_NUM;break;
 case 'both':$type=MYSQL_BOTH;break;
 }

 $arr=array();
 while($row=mysql_fetch_array($r,$type))
	 $arr[]=$row;
 mysql_free_result($r); 

 if(!empty($arr))
    return $arr;
 else
	return null;
 }
 public function add($str)
 {
 $r=mysql_query($str);
 if($r===false)
  throw new OtionException('添加记录失败！相应的sql语句为:'.$str);
 return $r; 
 }
 public function delete($str)
 {
 $r=mysql_query($str);
 if($r===false)
  throw new OtionException('删除记录失败！相应的sql语句为:'.$str);
 return $r; 
 }
 public function update($str)
 {
 $r=mysql_query($str);
 if($r===false)
  throw new OtionException('更新记录失败！相应的sql语句为:'.$str);
 return $r; 
 }
 public function last_insert_id()
 {
 $r=mysql_insert_id();
 if($r===false)
  throw new OtionException('获取添加的最后一条记录的id值失败！');
 return $r; 
 }
}
//=======使用sqlite方式连接sqlite数据库
class DBsqlite_sqlite implements IDB
{
 private $db;
 private $db_fetch_type;
 private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {
 }

 public function __construct($sqlite_db_path='',$db_fetch_type='')
 {
  $conf=Config::getInstance();

  if($sqlite_db_path=='')  
	  $sqlite_db_path=$conf->get_attribute('sqlite_db_path');
  if($db_fetch_type=='')  
	  $db_fetch_type=$conf->get_attribute('db_fetch_type');

  $this->db_fetch_type=$db_fetch_type;//返回数据库查询结果的形式

  $db=sqlite_open($sqlite_db_path);
  if($db===false)
   throw new OtionException('连接数据库失败！');

  $this->db=$db;
 }

 public function query($str,$get_result_set)
 {
 $r=sqlite_query($this->db,$str);
 if($r===false)
   throw new OtionException('查询记录失败！相应的sql语句为:'.$str);

 if($get_result_set===true)//若要求直接返回结果集
	 return $r;

 $db_fetch_type=$this->db_fetch_type==''?Config::getInstance()->get_attribute('db_fetch_type'):$this->db_fetch_type;
 switch(strtolower($db_fetch_type))
 {
 case 'assoc':$type=SQLITE_ASSOC;break;
 case 'num':$type=SQLITE_NUM;break;
 case 'both':$type=SQLITE_BOTH;break;
 }

 $arr=array();
 while($row=sqlite_fetch_array($r,$type))
	 $arr[]=$row;
 if(!empty($arr))
    return $arr;
 else
	return null;
 }
 public function add($str)
 {
 $r=sqlite_query($this->db,$str);
 if($r===false)
   throw new OtionException('添加记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function delete($str)
 {
 $r=sqlite_query($this->db,$str);
 if($r===false)
   throw new OtionException('删除记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function update($str)
 {
 $r=sqlite_query($this->db,$str);
 if($r===false)
   throw new OtionException('更新记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function last_insert_id()
 {
 $r=sqlite_last_insert_rowid($this->db);//注意，这里返回的是数据库内建的索引id值，而非数据表中自定义的id值
 if($r===false)
   throw new OtionException('获取添加的最后一条记录的id值失败！');
 return $r;
 }
}

//=====================================使用PDO连接数据库=======================
//pdo类公共操作：
class DBpdo implements IDB
{
 public function query($str,$get_result_set)
 {
 $r=$this->pdo->query($str);
 if($r===false)
	 throw new OtionException('查询记录失败！相应的sql语句为:'.$str);

 if($get_result_set===true)//若要求直接返回结果集
	 return $r;

 $db_fetch_type=Config::getInstance()->get_attribute('db_fetch_type');
 switch(strtolower($db_fetch_type))
 {
 case 'assoc':$type=PDO::FETCH_ASSOC;break;
 case 'num':$type=PDO::FETCH_NUM;break;
 case 'both':$type=PDO::FETCH_BOTH;break;
 }


 $arr=$r->fetchAll($type);
 if(!empty($arr))
    return $arr;
 else
	return null;
 }
 public function add($str)
 {
 $r=$this->pdo->exec($str);
 if($r===false)
	 throw new OtionException('添加记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function delete($str)
 {
 $r=$this->pdo->exec($str);
  if($r===0)
	 throw new OtionException('删除记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function update($str)
 {
 $r=$this->pdo->exec($str);
 if($r===0)
   throw new OtionException('更新记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function last_insert_id()
 {
 $r=$this->pdo->lastInsertId();
 if($r==0)
	 throw new OtionException('获取添加的最后一条记录的id值失败！');
 return $r;
 }
 public function getAttribute($name)//获取PDO对象的属性
 {
 return $this->pdo->getAttribute($name);dump($r);
 }
 public function setAttribute($name,$value)//设置PDO对象的属性
 {
 return $this->pdo->setAttribute($name,$value);
 }
 public function beginTransaction()//事务开始
 {
 return $this->pdo->beginTransaction();
 }
 public function commit()//事务完成
 {
 return $this->pdo->commit();
 }
 public function rollback()//事务回滚
 {
 return $this->pdo->rollback();
 }
 public function prepare($str)//准备语句
 {
 return $this->pdo->prepare($str);
 }

}
//=======使用pdo方式连接mysql数据库
class DBpdo_mysql extends DBpdo
{
 protected  $pdo;

 private static $instance=null;//保存自身实例(单例模式)

 public static function getInstance()//返回一个自身的实例(单例模式)
 { 
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
 }
 private function __clone()
 {
 }

 public function __construct($db_name='',$db_host='',$db_user='',$db_psw='',$db_charset='')
 {
  $conf=Config::getInstance();

  if($db_name=='')  
	  $db_name=$conf->get_attribute('db_name');
  if($db_host=='')  
	  $db_host=$conf->get_attribute('db_host');
  if($db_user=='')  
	  $db_user=$conf->get_attribute('db_user');
  if($db_psw=='')  
	  $db_psw=$conf->get_attribute('db_psw');
  if($db_charset=='')  
	  $db_charset=$conf->get_attribute('db_charset');

  try
  {
  $dsn="mysql:host=".$db_host.";dbname=".$db_name;
  $pdo=new PDO($dsn,$db_user,$db_psw);
  $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);//禁用仿真预处理语句(同时也就启用了真正预处理语句real parepared statements),从而防范sql注入攻击
  }
  catch(PDOException $e)
  {
  throw new OtionException('连接数据库失败！'.$e->getMessage());//重掷异常
  }
 
  $r=$pdo->query("set names ".$db_charset);
  if($r===false)
	  throw new OtionException('设置数据库字符集编码'.$db_charset.'失败！');

  $this->pdo=$pdo;
 }
}
//=======使用pdo方式连接sqlite数据库
class DBpdo_sqlite extends DBpdo
{
 protected  $pdo;

 private static $instance=null;//保存自身实例(单例模式)

 public static function getInstance()//返回一个自身的实例(单例模式)
 { 
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
 }
 private function __clone()
 {
 }

 public function __construct($sqlite_db_path='')
 {

  $conf=Config::getInstance();

  if($sqlite_db_path=='')  
	  $sqlite_db_path=$conf->get_attribute('sqlite_db_path');

  try
  {
  $pdo=new PDO("sqlite:".$sqlite_db_path);
  }
  catch(PDOException $e)
  {
  throw new OtionException('连接数据库失败！'.$e->getMessage());//重掷异常
  }

  $this->pdo=$pdo;
 }

}


//=====================================使用ADODB连接数据库=======================
//ADODB类公共操作：
class DBadodb implements IDB
{
 public function query($str,$get_result_set)
 {
 $r=$this->adodb->Execute($str);
 if($r===false)
	 throw new OtionException('查询记录失败！相应的sql语句为:'.$str);

 if($get_result_set===true)//若要求直接返回结果集
	 return $r;

 $db_fetch_type=Config::getInstance()->get_attribute('db_fetch_type');
 switch(strtolower($db_fetch_type))
 {
 case 'assoc':$type=ADODB_FETCH_ASSOC;break;
 case 'num':$type=ADODB_FETCH_NUM;break;
 case 'both':$type='';break;//==
 }
 $this->adodb->SetFetchMode($type);

 $arr=array();
 while($row=$r->fetchRow())
 {
 $arr[]=$row;
 }

 if(!empty($arr))
    return $arr;
 else
	return null;
 }
 public function add($str)
 {
 $r=$this->adodb->Execute($str);
 if($r===false)
	 throw new OtionException('添加记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function delete($str)
 {
 $r=$this->adodb->Execute($str);
  if($r===0)
	 throw new OtionException('删除记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function update($str)
 {
 $r=$this->adodb->Execute($str);
 if($r===0)
   throw new OtionException('更新记录失败！相应的sql语句为:'.$str);
 return $r;
 }
 public function last_insert_id()
 {
 $r=$this->adodb->Insert_ID();
 if($r==0)
	 throw new OtionException('获取添加的最后一条记录的id值失败！');
 return $r;
 }
}
//=======使用adodb方式连接mysql数据库
class DBadodb_mysql extends DBadodb
{
 protected $adodb;

 private static $instance=null;//保存自身实例(单例模式)
 public static function getInstance()//返回一个自身的实例(单例模式)
 { 
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }
  return self::$instance;
 }
 private function __clone()
 {
 }

 public function __construct($db_name='',$db_host='',$db_user='',$db_psw='',$db_charset='')
 {
  $conf=Config::getInstance();

  if($db_name=='')  
	  $db_name=$conf->get_attribute('db_name');
  if($db_host=='')  
	  $db_host=$conf->get_attribute('db_host');
  if($db_user=='')  
	  $db_user=$conf->get_attribute('db_user');
  if($db_psw=='')  
	  $db_psw=$conf->get_attribute('db_psw');
  if($db_charset=='')  
	  $db_charset=$conf->get_attribute('db_charset');

  include_once(otion_path."/Extend/data/adodb5/adodb.inc.php");  //注意相对路径
  $adodb = NewADOConnection ('mysql');
  $link=$adodb->Connect($db_host,$db_user,$db_psw,$db_name);
  if($link==false)
     throw new OtionException('连接数据库失败！');

 
  $r=$adodb->Execute("set names ".$db_charset);
  if($r===false)
	  throw new OtionException('设置数据库字符集编码'.$db_charset.'失败！');
  
  $this->adodb=$adodb;
 }
}
