<?php

// ============ModelOperate类(专门用于执行模型操作的类)===================
class ModelOperate extends ModelSetAttribute // 专门用于执行模型操作的类
{
	
	// ==使用memcache缓解数据库压力:==
	final public function memcached_select($query, $get_result_set = false)
	{
		$conf = Config::getInstance ();
		
		if ($conf->get_attribute ( 'open_cache' )) // 若开启了缓存
		{
			if ($conf->get_attribute ( 'cache_encrypt' )) // 若有对缓存内容加密
			{
				$value = $this->get_attribute ( 'memcache' )->get ( md5 ( $query ) );
				$value = Common::getInstance ()->decrypt ( $value, $conf->get_attribute ( 'crypt_key' ) ); // 解密
			}
			else
				$value = $this->get_attribute ( 'memcache' )->get ( $query );
			
			if ($value) // 若已设置对应的缓存记录
			{
				return $value;
			}
			else // 若未设置对应的缓存记录
			{
			    
				$r = $this->get_attribute ( 'db' )->query ( $query, $get_result_set ); // 执行数据库查询操作


				if ($conf->get_attribute ( 'cache_encrypt' )) // 若要对缓存内容加密
				{
					$r2 = Common::getInstance()->encrypt ( $r, $conf->get_attribute ( 'crypt_key' ) ); // 加密
					$this->get_attribute ( 'memcache' )->set ( md5 ( $query ), $r2, MEMCACHE_COMPRESSED, $conf->get_attribute ( 'cache_save_time' ) ); // 存入缓存
				}
				else
					$this->get_attribute ( 'memcache' )->set ( $query, $r, MEMCACHE_COMPRESSED, $conf->get_attribute ( 'cache_save_time' ) ); // 存入缓存
				
			    $this->clear_attr();//在执行数据库语句后清除Model对象的各相关属性
				return $r; // 返回数据库查询结果
			}
		}
		else // 若未开启缓存
		{
			$r = $this->get_attribute ( 'db' )->query ( $query, $get_result_set ); // 执行数据库查询操作

			$this->clear_attr();//在执行数据库语句后清除Model对象的各相关属性
			return $r; // 返回数据库查询结果
		}
	}
	final public function add() // 添加
	{
		$datas = $this->get_attribute ( 'data' );
		
		$query = "insert into " . $this->get_attribute ( 'tableName' ) . "(";
		$q2 = '';
		$q3 = '';
		foreach ( $datas as $key => $value )
		{
			if ($q2)
				$q2 .= ',';
			$q2 .= '`' . $key . '`';
			
			if ($q3)
				$q3 .= ',';
			$q3 .= "'" . $value . "'";
		}
		
		$query .= $q2 . ')values(' . $q3 . ')';
		$this->set_attribute ( 'sqlStr', $query );
		$r = $this->get_attribute ( 'db' )->add ( $query );
		$this->clear_attr();//在执行数据库语句后清除Model对象的各相关属性
		return $r;
	}
	final public function delete() // 删除
	{
		$query = 'delete from ' . $this->get_attribute ( 'tableName' ) . $this->get_attribute ( 'where' );
		$this->set_attribute ( 'sqlStr', $query );
		$r = $this->get_attribute ( 'db' )->delete ( $query );
		$this->clear_attr();//在执行数据库语句后清除Model对象的各相关属性
		return $r;
	}
	final public function save() // 修改
	{
		$query = "update " . $this->get_attribute ( 'tableName' ) . " set ";
		$q2 = '';
		foreach ( $this->get_attribute ( 'data' ) as $key => $value )
		{
			if ($q2)
				$q2 .= ',';
			
			$q2 .= '`' . $key . "`='" . $value . "'";
		}
		$query .= $q2 . $this->get_attribute ( 'where' );
		$this->set_attribute ( 'sqlStr', $query );
		$r = $this->get_attribute ( 'db' )->update ( $query );
		$this->clear_attr();//在执行数据库语句后清除Model对象的各相关属性
		return $r;
	}
	final public function getField($arr) // getField(),查询（返回只包含指定字段的结果集）
	{
		if (! is_array ( $arr ))
			$fields = $arr;
		else
		{
			foreach ( $arr as $item )
			{
				if (! isset ( $fields ))
					$fields = $item;
				else $fields .= ',' . $item;
			}
		}
		
		$arr = array ();
		
		$db_type = Config::getInstance ()->get_attribute ( 'db_type' );
		if ($this->get_attribute ( 'group' ) && ! $this->get_attribute ( 'order' ) && $db_type == 'mysql')
		{
			$this->set_attribute ( 'order', ' order by null' );
			// 对于mysql数据库,使用group by分组查询时,即使没有写order by,默认在分组后也会分别对各组内的记录进行排序,可能会降低速度.当没有order by语句的要求时,在group by后面增加order by null就可以防止排序
		}
		
		$query = 'select ' . $this->get_attribute ( 'distinct' ) . ' ' . $fields . ' from ' . $this->get_attribute ( 'tableName' ) . $this->get_attribute ( 'where' ) . $this->get_attribute ( 'group' ) . $this->get_attribute ( 'having' ) . $this->get_attribute ( 'order' ) . $this->get_attribute ( 'limit' );
		
		$this->set_attribute ( 'sqlStr', $query );
		
		$arr = $this->memcached_select ( $query ); // 根据查询结果是否已经缓存确定是否去查询数据库
		
		return $arr;
	}
	final public function select() // select(),查询(返回结果集)
	{
		return $this->getField ( '*' );
	}
	final public function find() // find(),查询(只返回一条记录)
	{
		$this->set_attribute ( 'limit', ' limit 1' );
		$arr = $this->getField ( '*' );
		
		return @$arr [0];
	}
	final public function count($field = '*') // 计算总个数
	{
		if ($field != '*')
			$field = '`' . $field . '`';
		$arr = $this->getField ( 'count(' . $field . ')' );
		return $arr [0] ['count(' . $field . ')'];
	}
	final public function sum($field) // 计算总和
	{
		$arr = $this->getField ( 'sum(`' . $field . '`)' );
		return $arr [0] ['sum(`' . $field . '`)'];
	}
	final public function avg($field) // 计算平均值
	{
		$arr = $this->getField ( 'avg(`' . $field . '`)' );
		return $arr [0] ['avg(`' . $field . '`)'];
	}
	final public function max($field) // 计算最大值
	{
		$arr = $this->getField ( 'max(`' . $field . '`)' );
		return $arr [0] ['max(`' . $field . '`)'];
	}
	final public function min($field) // 计算最小值
	{
		$arr = $this->getField ( 'min(`' . $field . '`)' );
		return $arr [0] ['min(`' . $field . '`)'];
	}
	final public function query($query, $get_result_set = false) // 直接执行完整数据库语句,第二个参数表示是否直接返回结果集
	{
		$this->set_attribute ( 'sqlStr', $query );
		
		if (strpos ( strtolower ( $query ), 'update' ) === 0)
		{
			$arr = $this->get_attribute ( 'db' )->update ( $query );
		}
		elseif (strpos ( strtolower ( $query ), 'insert' ) === 0)
		{
			$arr = $this->get_attribute ( 'db' )->add ( $query );
		}
		elseif (strpos ( strtolower ( $query ), 'delete' ) === 0)
		{
			$arr = $this->get_attribute ( 'db' )->delete ( $query );
		}
		else
		{
			$arr = $this->memcached_select ( $query, $get_result_set ); // 根据查询结果是否已经缓存确定是否去查询数据库
		}
		
		return $arr;
	}
	final public function last_insert_id() // 获取上次插入的最后一条记录的id值
	{
		return $this->get_attribute ( 'db' )->last_insert_id ();
	}
	
	// ===pdo类操作===
	final public function pdo_getAttribute($name) // 获取属性
	{
		return $this->get_attribute ( 'db' )->getAttribute ( $name );
	}
	final public function pdo_setAttribute($name, $value) // 设置属性
	{
		return $this->get_attribute ( 'db' )->setAttribute ( $name, $value );
	}
	final public function pdo_beginTransaction() // 事务开始
	{
		return $this->get_attribute ( 'db' )->beginTransaction ();
	}
	final public function pdo_commit() // 事务完成
	{
		return $this->get_attribute ( 'db' )->commit ();
	}
	final public function pdo_rollback() // 事务回滚
	{
		return $this->get_attribute ( 'db' )->rollback ();
	}
	final public function pdo_prepare($str) // pdo准备语句
	{
		return $this->get_attribute ( 'db' )->prepare ( $str );
	}
}
