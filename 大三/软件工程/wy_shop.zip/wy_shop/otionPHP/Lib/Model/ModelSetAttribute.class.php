<?php
//============ModelSetAttribute类(专门用于设置Model属性值的类)===========
class ModelSetAttribute//专门用于设置Model属性值的类
{
 private $db;
 private $tableName;
 private $where='';
 private $data='';
 private $order='';
 private $limit='';
 private $distinct='';
 private $group='';
 private $having='';
 private $sqlStr='';//sql语句
 private $memcache;//memcache缓存服务器对象


public function get_attribute($name)//读取属性值
{
if(isset($this->$name)) 
	{
    return $this->$name;
	}
else
	throw new OtionException('属性'.$name.'不存在！');
}
public function set_attribute($name,$value)//设置属性值
{
$this->$name=$value;
}
public function getSqlStr()//获取数据库执行语句
{
 return $this->get_attribute('sqlStr');
}
public function clear_attr()//在执行数据库语句后清除Model对象的各相关属性
{
 $this->set_attribute('where','');
 $this->set_attribute('data','');
 $this->set_attribute('order','');
 $this->set_attribute('limit','');
 $this->set_attribute('distinct','');
 $this->set_attribute('group','');
 $this->set_attribute('having','');
}
//=======以下为where设置
final public function where($par)
 {
 if(is_string($par))//如果参数是字符串
	$where=' where '.$par;
 elseif(is_array($par))//如果参数是数组
    $where=$this->where_array_parameter($par);
 
 $this->set_attribute('where',$where);
 return $this;
 }

final public function where_array_parameter($arr)//当参数为数组时where的设置
 {
   $arr['_logic']=isset($arr['_logic'])?$arr['_logic']:'and';
   foreach($arr as $key=>$value)
   {
     if($key=='_logic') 
	    continue;
  
	 if(!isset($where)) 
		 $where=' where (';
	 else
		 $where.=') '.$arr['_logic'].' (';
		 
     if(!is_array($value))//若参数是一维数组，例如$where['id']=3;
	  {
    	 $where.='`'.$key."`='".$value."'";
	  }
	 else       //若参数是二维或三维数组，例如$where[id]=array('gt',3);或$where[id]=array('in',array(1,2,3));
	  {
      $where=$this->where_2_or_3_array_parameter($where,$key,$value);   
      }
  

   }
   $where.=')';
   
   return $where;
 }


final public function where_2_or_3_array_parameter($where,$key,$value)//当参数是二维或三维数组时where的设置
 {
	   if(!is_array($value[1]))//若参数是二维数组，即$value[1]是字符串或整型变量
	   {
	    switch(strtolower($value[0]))
	    {
	    case 'lt':$cmp='<';break;
	    case 'elt':$cmp='<=';break;
	    case 'eq':$cmp='=';break;
	    case 'neq':$cmp='!=';break;
	    case 'egt':$cmp='>=';break;
	    case 'gt':$cmp='>';break;
        default  :$cmp=$value[0];break;//若是直接给出<,=,<=等，或$where['name']=array('like','光%');
	    }
	    $where.='`'.$key.'` '.$cmp.' "'.$value[1].'"';
	   }
	   else                 //若参数是三维数组，即$value[1]是数组
	   {
       $where=$this->where_3_array_parameter($where,$key,$value);
	   }
	return $where;
 }
 final public function where_3_array_parameter($where,$key,$value)//当参数是三维数组时where的设置
 {
 	   if(strtolower($value[0])=='between'||strtolower($value[0])=='not between')//若是(not) between
	   { 
           $where.='`'.$key.'` '.strtolower($value[0]).' '.$value[1][0].' and '.$value[1][1];
	   }
	   elseif(strtolower($value[0])=='in'||strtolower($value[0])=='not in')//若是(not) in
	   {
           $where.='`'.$key.'` '.strtolower($value[0]).'(';
           foreach($value[1] as $item)
			  {
			   if($item==$value[1][0])
			   $where.=$item;
			   else
			   $where.=','.$item;
			  }
		   $where.=')';
	   }
	   elseif(strtolower($value[0])=='like'||strtolower($value[0])=='not like')//若是(not) like		
	   {
		   $logic=isset($value[2])?$value[2]:'or';
           foreach($value[1] as $item)
			  {
			   if($item==$value[1][0])
			   $where.='`'.$key.'` '.strtolower($value[0]).' "'.$item.'"';
			   else
			   $where.=' '.$logic.' `'.$key.'` '.strtolower($value[0]).' "'.$item.'"';
			  }	  
	   }
	return $where;
 }

//=========以上为where设置
 final public function data($arr)//=======data设置
 {
 $this->set_attribute('data',$arr);
 return $this;
 }
 final public function order($str)//=======order设置
 {
 $this->set_attribute('order',' order by '.$str);
 return $this;
 }
 final public function limit($str)//=======limit设置
 {
 $this->set_attribute('limit',' limit '.$str);
 return $this;
 }
 final public function distinct($str='true')//=======distinct设置
 {
  if($str=='true')
  $this->set_attribute('distinct','distinct');
  else
  $this->set_attribute('distinct','');

  return $this;
 }
 final public function group($str)//=======group设置
 {
  $this->set_attribute('group',' group by `'.$str.'`');
  return $this;
 }
 final public function having($str)//=======having设置
 {
  $this->set_attribute('having',' having '.$str);
  return $this;
 }
}


