<?php
class Action extends Common
{
 final public function M($tableName='')//实例化model类的简便方法
 {
 return  Model::getInstance($tableName);
 }
 final public function flush_static_web_page($url)//强制刷新指定的静态页面
 {
  $_SESSION['flush_'.__APP__.'/'.$url]=1;
 }
 final public function assign($key,$value)//给模板变量赋值
 {
  Tpl_engine::getInstance()->assign($key,$value);
 } 
 final public function display($tpl='')//调用模板进行显示
 {
  Tpl_engine::getInstance()->display($tpl);
 }
 final public function show($content)//直接解析内容（而非读取模板文件）
 {
  Tpl_engine::getInstance()->show($content);
 }
 final public function memcache_clear()//清空所有的memecache缓存记录
 {
 $m=CommonMemcache::getInstance();
 $m->flush();
 }
 final public function memcache_set($name,$value,$save_time,$type=MEMCACHE_COMPRESSED)//设置memecache缓存记录
 {
 $m=CommonMemcache::getInstance();
 $m->set($name,$value,$type,$save_time);
 }
 final public function memcache_get($name)//获取memecache缓存记录
 {
 $m=CommonMemcache::getInstance();
 return $m->get($name);
 }
}
