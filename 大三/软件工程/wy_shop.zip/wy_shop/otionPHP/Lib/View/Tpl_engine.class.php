<?php
class Tpl_engine
{
 private $vars;//存放模板变量

 private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {
 }
 private function __construct()
 {
	  $this->vars=array
      (
	  'get'=>$_GET,
      'post'=>$_POST,
	  'server'=>$_SERVER,
	  'session'=>$_SESSION,
	  'cookie'=>$_COOKIE,
	  'request'=>$_REQUEST,//能同时获取get和post传递的数据，但比较慢
      );
 }

 final public function assign($key,$value)//给模板变量赋值
 {

 $this->vars[$key]=$value;
 }

 final public function display($tpl='')//调用模板进行显示
 {
   $model=Common::getInstance()->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的模块名称
   $action=Common::getInstance()->getFuncName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的方法名称

   if($tpl)//若形参$tpl不为空
   {
     if(substr_count($tpl,'/')==2)//若$tpl形如'blue_theme/Index/index'
	 {
	 $arr=explode('/',$tpl);
	 $theme=$arr[0];
	 $m=$arr[1];
	 $a=$arr[2];
	 }
     else     
     if(substr_count($tpl,'/')==1)//若$tpl形如'User/test'
	 {
	 $arr=explode('/',$tpl);
	 $m=$arr[0];
	 $a=$arr[1];
	 }
     else                       //若$tpl形如'test'
	 {
     $m=$model;
     $a=$tpl;
     }
   }
   else//若形参$tpl为空
   {
   $m=$model;
   $a=$action;
   }
  
     $tpl=$a.Config::getInstance()->get_attribute('tmpl_suffix');//添加后缀名
     
	 if(false==(isset($theme)&&$theme))//若没有指定模板主题
	 $theme=(Config::getInstance()->get_attribute('default_theme'))?(Config::getInstance()->get_attribute('default_theme').'/'):'';
     else
	 {
		 if(in_array($theme,Config::getInstance()->get_attribute('theme_list')))
		 $theme.='/';
	     else
		   throw new OtionException('指定的模板主题'.$theme.'不存在！');
	 }
     

     $tpl_file=Config::getInstance()->get_attribute('tpl_path').'/'. $theme.$m.'/'.$tpl;
     if(!file_exists($tpl_file))
		 throw new OtionException('指定的模板文件'.$tpl_file.'不存在！');

     $file_name=Common::getInstance()->filename_deal($theme.'_'.$m.'_'.$tpl.'.php');//去除不允许出现在文件名中的字符
     $com_file=Config::getInstance()->get_attribute('com_path').'/'.$file_name;
 

	 if(!file_exists($com_file)||(filemtime($tpl_file)>filemtime($com_file)))
	 {
     $file=fopen($tpl_file,'rb');
	 if($file===false)
		 throw new OtionException('读取文件'.$tpl_file.'的内容失败！');

     $content='';
     while(!feof($file))//如没有达到文件的末尾
       $content.=fgets($file);//每次读取一行，进行拼接
	 fclose($file);
     
	 $this->tpl_replace($content,$com_file);
	 }

     include($com_file);

 }
 final private function tpl_replace($content,$com_file)//替换模板中的标签
 {

//替换系统常量
		$constant=Config::getInstance()->system_constant();
        foreach($constant as $key=>$value)
           $content=str_replace($key, '<?php echo"'.$value.'"; ?>', $content); 

        $left=Config::getInstance()->get_attribute('tmpl_l_delim');//左定界符
        $right=Config::getInstance()->get_attribute('tmpl_r_delim');//右定界符

// 使用str_replace()替换模板标签
        $content=str_replace($left.'else'.$right, '<?php } else {?>', $content);
		$content=str_replace($left.'/if'.$right, '<?php } ?>', $content);

        $content=str_replace($left.'foreachelse'.$right, '<?php } else {?>', $content);
        $content=str_replace($left.'/foreach'.$right, '<?php } ?>', $content); 

		$content=str_replace($left.'/switch'.$right, '<?php } ?>', $content); 

 		$content=str_replace($left.'/for'.$right, '<?php } ?>', $content);

// 使用preg_replace()替换模板标签
       // 将被替代的模板标签 
      $pattern=array(
	   '/'.$left.'\s*\$otion\.get\.(\w+)\s*\\'.$right.'/',//{$otion.get.id}
	   '/'.$left.'\s*\$otion\.post\.(\w+)\s*\\'.$right.'/',//{$otion.post.name}
	   '/'.$left.'\s*\$otion\.server\.(\w+)\s*\\'.$right.'/',//{$otion.server.name}
	   '/'.$left.'\s*\$otion\.session\.(\w+)\s*\\'.$right.'/',//{$otion.session.id}
	   '/'.$left.'\s*\$otion\.cookie\.(\w+)\s*\\'.$right.'/',//{$otion.cookie.name}
	   '/'.$left.'\s*\$otion\.request\.(\w+)\s*\\'.$right.'/',//{$otion.request.name}


      '/\$(\w+)/',//$name

      '/\$this\->vars\[\'(\w+)\'\]\.(\w+)/',
		   //$this->vars['list'].id


	  // ++$score
      '/'.$left.'\s*\+\+\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\s*\\'.$right.'/',
	  // $score++
      '/'.$left.'\s*\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\+\+\s*\\'.$right.'/',
      // --$score		                                                                                 
      '/'.$left.'\s*\-\-\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\s*\\'.$right.'/',
      // $score--		                                                                                 
      '/'.$left.'\s*\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\-\-\s*\\'.$right.'/',

      // {$score +, -, *, /, %, +=, -=, *=, /=, %=77}
	  '/'.$left.'\s*\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\s*(\+|\-|\*|\/|%|\+=|\-=|\*=|\/=|%=)\s*([0-9]+)\s*\\'.$right.'/',     
      // {$score +, -, *, /, %, +=, -=, *=, /=, %=$score}
	  '/'.$left.'\s*\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\s*(\+|\-|\*|\/|%|\+=|\-=|\*=|\/=|%=)\s*\$this\->vars\[\'(\w+)\'\]((\[\'\w+\'\])*)\s*\\'.$right.'/',
 

      '/'.$left.'\s*\$this\->vars\[\'(\w+)\'\]((\[(\'|"|)\w+(\'|"|)\])*)\s*\\'.$right.'/',
		   //{$this->vars['name']}或{$this->vars['list']['id']}以及更多维的数组元素
	 

	  '/'.$left.'\s*if\s*\((.*)\)\s*\\'.$right.'/',//{if ($sex=='man')}
      '/'.$left.'\s*elseif\s*\((.*)\)\s*\\'.$right.'/',//{elseif ($sex=='woman')}

      '/'.$left.'\s*foreach\s*\(\s*\$(.*)\s+as\s+(.*)\s*\)\s*\\'.$right.'/',
		                                   //{foreach($list as $item)}或{foreach($list as $key=>$value)}

	  '/'.$left.'\s*switch\s*\((.*)\)\s*\\'.$right.'/',//{switch($sex)}
	  '/'.$left.'\s*case\s+(.*):(.*?);(.*)\\'.$right.'/',
		                                          //{case '男':man;break;}或{case '男':man;}
	  '/'.$left.'\s*default\s*:(.*?);(.*)\\'.$right.'/',
                                                  //{default:unknown;break;}或{default:unknown;}
	  '/'.$left.'\s*include\s+file\s*=(.*?)\\'.$right.'/',//{include file="min"}
      '/'.$left."\s*php\s*".$right."(.*)".$left."\s*\/php\s*".$right.'/',//{php}echo'这里是直接嵌入的php代码';{/php}

      '/'.$left.'\s*for\s*\((.*)\)\s*\\'.$right.'/',
		                                                             //{for($a=2;$a!=8;$a++)}
      );
        // 用于替代的php标签 
      $replacement=array(
	    
	   
	   '<?php if(isset($get[\'\1\'])) echo htmlspecialchars($get[\'\1\']);?>',//用htmlspecialchars()进行过滤
	   '<?php if(isset($post[\'\1\'])) echo htmlspecialchars($post[\'\1\']);?>',
	   '<?php if(isset($server[\'\1\'])) echo htmlspecialchars($server[\'\1\']);?>',
	   '<?php if(isset($session[\'\1\'])) echo htmlspecialchars($session[\'\1\']);?>',
	   '<?php if(isset($cookie[\'\1\'])) echo htmlspecialchars($cookie[\'\1\']);?>',
	   '<?php if(isset($request[\'\1\'])) echo htmlspecialchars($request[\'\1\']);?>',

       '$this->vars[\'\1\']',//$this->vars['name'] 

       '$this->vars[\'\1\'][\'\2\']',//$this->vars['list']['id']
       
	   // ++$score
       '<?php if(isset(\$this->vars[\'\1\']\2)) echo ++\$this->vars[\'\1\']\2;?>',
	   // $score++
       '<?php if(isset(\$this->vars[\'\1\']\2)) echo \$this->vars[\'\1\']\2++;?>',
	   // --$score
       '<?php if(isset(\$this->vars[\'\1\']\2)) echo --\$this->vars[\'\1\']\2;?>',
	   // $score--
       '<?php if(isset(\$this->vars[\'\1\']\2)) echo \$this->vars[\'\1\']\2--;?>',

       //$score +, -, *, /, %, +=, -=, *=, /=, %=77
	   '<?php if(isset(\$this->vars[\'\1\']\2)) echo \$this->vars[\'\1\']\2\4\5;?>',
	   //$score +, -, *, /, %, +=, -=, *=, /=, %=$score
       '<?php if(isset(\$this->vars[\'\1\']\2)&&isset(\$this->vars[\'\5\']\6)) echo \$this->vars[\'\1\']\2\4\$this->vars[\'\5\']\6;?>', 
 

       '<?php if(isset(\$this->vars[\'\1\']\2)) echo \$this->vars[\'\1\']\2;?>', 
		                  //<?php if(isset($this->vars['list']['id']))echo $this->vars['list']['id'];? >或<?php if(isset($this->vars['name'])) echo $this->vars['name'];? >以及更多维的数组元素

       '<?php if(\1) {?>',//if标签
       '<?php } elseif(\1) {?>',//elseif标签

	   '<?php if (count((array)\$\1)) foreach((array)\$\1 as \2) {?>',//foreach标签

	   '<?php  if(isset(\1)) switch(\1) {?>',   //switch标签   
	   '<?php case \1: echo "\2";\3 ?>', //case标签
	   '<?php default: echo "\1";\2 ?>', //default标签

	   '<?php $this->display(\1)?>',//include标签
	   '<?php \1?>',//php标签
	   '<?php for(\1){?>',//for标签
        );
        // 执行替换操作（各数组元素一一对应） 
        $content = preg_replace($pattern, $replacement, $content);
//实现表单令牌验证功能
 $conf=Config::getInstance();
 $token_open=$conf->get_attribute('token_open');
 if($token_open==true)
 {
	 $_SESSION['otionPHP_token']=rand(1,100000);
	 $content=str_replace('</form>',"<input type='hidden' name='otionPHP_token' value='".$_SESSION['otionPHP_token']."'></form>",$content);
 }

       $file=fopen($com_file,'wb');
	   if($file===false)
		  throw new OtionException('向文件'.$com_file.'写入内容失败！');
       fwrite($file,$content);
	   fclose($file);

 }
 final public function show($content)//直接解析内容（而非读取模板文件）
 {
   $model=Common::getInstance()->getModelName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的模块名称
   $action=Common::getInstance()->getFuncName($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);//获取当前使用的方法名称

   $com_file=Config::getInstance()->get_attribute('com_path').'/'.$model.'_'.$action.'_show.php';
   $this->tpl_replace($content,$com_file);
   include($com_file);
 }
}

