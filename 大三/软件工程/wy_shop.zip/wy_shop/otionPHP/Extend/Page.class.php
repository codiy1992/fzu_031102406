<?php
class Page
{
private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {}
 private function __construct()
 {}
public function page_cut($totle,$displaypg=20)//$totle记录总数,$displaypg每页显示记录数
{
$page = isset($_GET['page'])?$_GET['page']:1;

$url=$_SERVER["REQUEST_URI"];//$url赋值为本页URL

$url=preg_replace("/\/page\/".$page."/","",$url);//因为URL中可能包含了页码信息，我们要把它去掉，以便加入新的页码信息。

$url.="/page";//在URL后加page查询信息，但待赋值


//****************页码计算******
$lastpg=ceil($totle/$displaypg); //最后页，也是总页数
$page=min($lastpg,$page);

$prepg=$page-1; //上一页
$nextpg=($page==$lastpg ? 0 : $page+1); //下一页
$firstcount=($page-1)*$displaypg;

if ($firstcount<0)
	$firstcount=0;


$page_show="显示第 <B>".($totle?($firstcount+1):0)."</B>-<B>".min($firstcount+$displaypg,$totle)."</B> 条记录（共 $totle 条）&nbsp;&nbsp;";//分页导航条代码：


$page_show.=" <a href='$url/1'>首页</a> ";

if($prepg) 
	$page_show.=" <a href='$url/$prepg'>上一页</a> ";
else 
	$page_show.=" 上一页 ";

if($nextpg)
	$page_show.=" <a href='$url/$nextpg'>下一页</a> ";
else 
	$page_show.=" 下一页 ";


$page_show.=" <a href='$url/$lastpg'>尾页</a> ";


$page_show.="　到第<select name='topage' size='1' onchange='window.location=\"$url/\"+this.value'>\n";//下拉跳转列表，循环列出所有页码：
for($i=1;$i<=$lastpg;$i++)
{
if($i==$page)
$page_show.="<option value='$i' selected>$i</option>\n";
else
$page_show.="<option value='$i'>$i</option>\n";
}
$page_show.="</select>";


$page_show.="页，共 $lastpg 页";

   return array(
	'page_info'=>$page_show,
	'begin'=>$firstcount,
	'length'=>$displaypg,
   );
}
}





