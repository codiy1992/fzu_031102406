<?php
class SendEmail
{
private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {}
 private function __construct()
 {}

 public function index($sender,$key,$receiver,$title='',$content='',$Attachment='',$smtp='smtp.qq.com')//供外部调用
 {
require_once(otion_path.'/Extend/data/PHPMailer/class.phpmailer.php'); //载入PHPMailer类 
 
$mail = new PHPMailer(); //实例化 
$mail->IsSMTP(); // 启用SMTP 
$mail->Port = 25;  //邮件发送端口 
$mail->SMTPAuth   = true;  //启用SMTP认证 
$mail->CharSet  = "UTF-8"; //字符集 
$mail->Encoding = "base64"; //编码方式 


$mail->Host = $smtp; //SMTP服务器 默认使用qq邮箱 
$mail->Username = $sender;  //发件人邮箱 
$mail->Password = $key;  //发件人密码 
$mail->AddAddress($receiver,"");//收件人邮箱
$mail->Subject =$title; //邮件标题 
$mail->Body = $content; //邮件主体内容  
$mail->AddAttachment($Attachment,basename($Attachment)); // 添加附件,并指定名称 

$mail->From = $sender;  //发件人地址（也就是你的邮箱） 
$mail->FromName = $sender;  //发件人姓名 
 
 
$mail->IsHTML(true); //支持html格式内容 

 
//发送 
if(!$mail->Send())
	return false;
else
	return true;
 
 }
}
