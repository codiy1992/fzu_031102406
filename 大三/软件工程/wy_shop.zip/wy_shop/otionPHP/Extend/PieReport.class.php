<?php     
class PieReport
{     
 private $width=550;//报表宽度
 private $height=250;//报表高度
 private $shadow=false;//是否显示画布阴影
 private $background='lightblue';//画布背景色
 private $background_image;//背景图片

 private $title='This is a report form';//报表标题
 private $title_size=14;//报表标题的大小
 private $title_color='black';//报表标题的颜色

 private $data=array(20,30,10);//统计数据
 
 private $legend_data=array(1,2,3);//图例内容
 private $legend_size=7;//图例文字大小
 private $legend_color='black';//图例文字的颜色

 private $pie_height;//饼图的高度
 private $pie_size;//饼图的大小
 private $angle=40;//饼图的角度
 private $pie_data_format;//饼图上数据的格式
 private $pie_data_size=8;//饼图上数据的文字大小
 private $pie_data_color;//饼图上数据的文字颜色
 private $pie_explode;//设置拆分饼图及各块距离

 private $x=0.4;//饼图在画布中的x位置
 private $y=0.5;//饼图在画布中的y位置

 private $legend_x=0.05;//图例在画布中的x位置
 private $legend_y=0.25;//图例在画布中的y位置

 private $save_as_file=false;//是否将生成的图片保存为文件
 private $save_path;//图片保存路径

 private static $instance=null;//保存自身实例(单例模式)

 public static function getInstance()//返回一个自身的实例(单例模式)
 {
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }
  return self::$instance;
 }
 private function __clone(){}

 private function _construct(){}

 public function get_attribute($name)//读取属性值
 {
 if(isset($this->$name)) 
     return $this->$name;
 else
	throw new OtionException('属性'.$name.'不存在！');
 }
 public function set_attribute($name,$value)//设置属性值
 {
 $this->$name=$value;
 }
 
 public function create()//生成报表
 {
 include(otion_path.'/Extend/data/jpgraph/jpgraph.php');
 include(otion_path.'/Extend/data/jpgraph/jpgraph_pie.php');
 include(otion_path.'/Extend/data/jpgraph/jpgraph_pie3d.php');

$graph = new PieGraph($this->get_attribute('width'),$this->get_attribute('height'));//设置整张报表的宽高
if($this->get_attribute('shadow')==true) //创建画布阴影
{
$graph->SetShadow(); 
}
$graph->SetMarginColor($this->get_attribute('background'));//设置画布背景色
if(isset($this->background_image)) //添加背景图片
{
$graph->SetBackgroundImage($this->get_attribute('background_image'),BGIMG_FILLFRAME);
}

$graph->title->Set($this->get_attribute('title'));//设置报表标题
$graph->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('title_size'));//设置标题的大小
$graph->title->setColor($this->get_attribute('title_color'));//设置标题的颜色

$graph->legend->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('legend_size'));//设置图例文字大小
$graph->legend->setColor($this->get_attribute('legend_color'));//设置图例文字颜色
$graph->legend->Pos($this->get_attribute('legend_x'),$this->get_attribute('legend_y'));//设置图例在画布的位置

$p=new PiePlot3D($this->get_attribute('data'));  //根据统计数据创建3D饼图对象
$p->SetLegends($this->get_attribute('legend_data'));//图例内容

$p->SetCenter($this->get_attribute('x'),$this->get_attribute('y'));  //设置饼图在画布的位置
$p->SetAngle($this->get_attribute('angle'));//设置饼图的角度
if(isset($this->pie_data_format))//设置饼图上数据的格式
{
$p->value->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('pie_data_size'));
$p->value->SetFormat($this->get_attribute('pie_data_format'));
}
if(isset($this->pie_data_color))//设置饼图上数据的颜色
{
$p->value->setColor($this->get_attribute('pie_data_color'));
}

if(isset($this->pie_height))//设置饼图高度
{
$p->SetHeight($this->get_attribute('pie_height'));
}
if(isset($this->pie_size))//设置饼图大小
{
$p->SetSize($this->get_attribute('pie_size'));
}
if(isset($this->pie_explode))//设置拆分饼图及各块距离.四个参数依次是饼图各部分与圆心的距离
{
$p->Explode($this->get_attribute('pie_explode'));
}
$graph->Add($p);  //将3D饼形图添加到图像中
if($this->get_attribute('save_as_file')==false)
$graph->Stroke();  //将图像输出到浏览器
else
$graph->Stroke($this->get_attribute('save_path'));  //将图像保存为文件

}

}    
 