<?php
class Image 
{ 
private static $instance=null;//保存自身实例(单例模式)

public static function getInstance()//返回一个自身的实例(单例模式)
{
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }

  return self::$instance;
}
 private function __clone()
 {}
 private function __construct()
 {}

    //生成非中文验证码(位数，类型【0:大小写字母;1:数字;2大写字母;3:小写字母】，图像格式，宽度，高度)
    public function buildImageVerify($length=4,$mode=0,$type='png',$width=48,$height=22,$verifyName='verify') 
	{
		$string=String::getInstance();
        $randval=$string->randString($length,$mode);//获得随机组成的字符串
		@session_start();
		$_SESSION[$verifyName]=md5(strtolower($randval));//验证时不区分大小写

        $width=($length*10+10)>$width?$length*10+10:$width;

        if($type!='gif'&&function_exists('imagecreatetruecolor'))
            $im=imagecreatetruecolor($width,$height); //生成画布
		else
            $im=imagecreate($width,$height);
        
        $r=Array(225,255,255,223);
        $g=Array(225,236,237,255);
        $b=Array(225,236,166,125);
 
        $backColor=imagecolorallocate($im,250,250,250);                  //背景色（随机）
        $borderColor=imagecolorallocate($im,100,100,100);                //边框色
        imagefilledrectangle($im,0,0,$width-1,$height-1,$backColor);
        imagerectangle($im,0,0,$width-1,$height-1,$borderColor);
        $lineColor=imagecolorallocate($im,mt_rand(0,200),mt_rand(0,120),mt_rand(0,120));
                                                                               // 干扰线的颜色
        $pointColor=imagecolorallocate($im,mt_rand(0,200),mt_rand(0,120),mt_rand(0,120));
                                                                               // 干扰点的颜色
        $stringColor=imagecolorallocate($im,mt_rand(0,200),mt_rand(0,120),mt_rand(0,120));
                                                                               //验证码的颜色	

       for($i=0;$i<5;$i++)//干扰线
       imagearc($im,mt_rand(-10,$width),mt_rand(-10,$height),mt_rand(30,300),mt_rand(20,200),55,44,$lineColor);
        
       for($i=0;$i<18;$i++)//干扰点
            imagesetpixel($im,mt_rand(0,$width),mt_rand(0,$height),$pointColor);
        
       for($i=0;$i<$length;$i++)//验证码
            imagestring($im,5,$i*10+5,mt_rand(1,8),$randval{$i},$stringColor);
        
       $this->output($im, $type);//输出图像
    }

    // 生成中文验证码(位数，图像格式，宽度，高度,字体),各参数均可省
    public function GBVerify($length=4, $type='png', $width=180, $height=50, $fontface='simfang.ttf', $verifyName='verify')
	{
		$string=String::getInstance();
        $code=$string->randString($length,4);
        $width=($length*45)>$width?$length*45:$width;
		@session_start();
        $_SESSION[$verifyName]=md5($code);
        $im=imagecreatetruecolor($width,$height);
        $borderColor=imagecolorallocate($im,100,100,100);                         //边框色
        $bkcolor=imagecolorallocate($im,250,250,250);                             //背景色
        imagefill($im,0,0,$bkcolor);
        imagerectangle($im,0,0,$width-1,$height-1,$borderColor);                 //干扰
        
        for($i=0;$i<15;$i++)
		{
            $fontcolor=imagecolorallocate($im,mt_rand(0,255),mt_rand(0,255),mt_rand(0,255));
            imagearc($im,mt_rand(-10,$width),mt_rand(-10,$height),mt_rand(30,300),mt_rand(20,200),55,44, $fontcolor);
        }
        for($i=0;$i<255;$i++) 
		{
            $fontcolor=imagecolorallocate($im,mt_rand(0,255),mt_rand(0,255),mt_rand(0,255));
            imagesetpixel($im,mt_rand(0,$width),mt_rand(0,$height),$fontcolor);
        }
        if(!is_file($fontface))
		{
            $fontface=otion_path."/Extend/data/".$fontface;
        }
        for($i=0;$i<$length;$i++)
		{
            $fontcolor=imagecolorallocate($im,mt_rand(0,120),mt_rand(0,120),mt_rand(0,120));//这样保证随机出来的颜色较深。
		    $string=String::getInstance();
            $codex=$string->msubstr($code,$i,1);
            imagettftext($im,mt_rand(16,20),mt_rand(-60,60),40*$i+20,mt_rand(30,35),$fontcolor,$fontface, $codex);
        }
        $this->output($im,$type);//输出图像
    }
  
   //输出图像
    public function output($im, $type='png', $filename='')
	{
        header("Content-type: image/" . $type);
        $ImageFun = 'image'.$type;
        if (empty($filename)) 
		{
            $ImageFun($im);
        } else
		{
            $ImageFun($im,$filename);
        }
        imagedestroy($im);
    }
	
	//取得图像信息
    public function getImageInfo($img) 
	{
        $imageInfo = getimagesize($img);
        if ($imageInfo !== false)
		{
            $imageType = strtolower(substr(image_type_to_extension($imageInfo[2]), 1));
            $imageSize = filesize($img);
            $info = array(
                "width" => $imageInfo[0],
                "height" => $imageInfo[1],
                "type" => $imageType,
                "size" => $imageSize,
                "mime" => $imageInfo['mime']
            );
            return $info;
        } 
		else 
		{
            return false;
        }
    }

	//生成缩略图(原图,缩略图文件名,图像格式,宽度,高度,启用隔行扫描)
    public function thumb($image, $thumbname, $type='', $maxWidth=200, $maxHeight=50, $interlace=true) 
	{
        // 获取原图信息
        $info = $this->getImageInfo($image);
        if ($info !== false) 
		{
            $srcWidth = $info['width'];//原图宽度
            $srcHeight = $info['height'];//原图高度
            $type = empty($type) ? $info['type'] : $type;
            $type = strtolower($type);
            $interlace = $interlace ? 1 : 0;
            unset($info);

            $scale = min($maxWidth / $srcWidth, $maxHeight / $srcHeight); // 计算缩放比例
            if ($scale >= 1) 
			{
                // 超过原图大小不再缩略
                $width = $srcWidth;
                $height = $srcHeight;
            } 
			else
			{
                // 缩略图尺寸
                $width = (int) ($srcWidth * $scale);
                $height = (int) ($srcHeight * $scale);
            }

            // 载入原图
            $createFun = 'ImageCreateFrom' . ($type == 'jpg' ? 'jpeg' : $type);
            if(!function_exists($createFun))
			{
                return false;
            }
            $srcImg = $createFun($image);

            //创建缩略图
            if ($type != 'gif' && function_exists('imagecreatetruecolor'))
                $thumbImg = imagecreatetruecolor($width, $height);
            else
                $thumbImg = imagecreate($width, $height);
              //png和gif的透明处理 by luofei614
            if('png'==$type)
			{
                imagealphablending($thumbImg, false);//取消默认的混色模式（为解决阴影为绿色的问题）
                imagesavealpha($thumbImg,true);//设定保存完整的 alpha 通道信息（为解决阴影为绿色的问题）    
            }elseif('gif'==$type)
			{
                $trnprt_indx = imagecolortransparent($srcImg);
                 if ($trnprt_indx >= 0)
			     {
                        //its transparent
                       $trnprt_color = imagecolorsforindex($srcImg , $trnprt_indx);
                       $trnprt_indx = imagecolorallocate($thumbImg, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
                       imagefill($thumbImg, 0, 0, $trnprt_indx);
                       imagecolortransparent($thumbImg, $trnprt_indx);
                 }
            }
            // 复制图片
            if (function_exists("ImageCopyResampled"))
                imagecopyresampled($thumbImg, $srcImg, 0, 0, 0, 0, $width, $height, $srcWidth, $srcHeight);
            else
                imagecopyresized($thumbImg, $srcImg, 0, 0, 0, 0, $width, $height, $srcWidth, $srcHeight);

            // 对jpeg图形设置隔行扫描
            if ('jpg' == $type || 'jpeg' == $type)
                imageinterlace($thumbImg, $interlace);

            // 生成图片
            $imageFun = 'image' . ($type == 'jpg' ? 'jpeg' : $type);
            $imageFun($thumbImg, $thumbname);
            imagedestroy($thumbImg);
            imagedestroy($srcImg);
            return $thumbname;
        }
        return false;
    }
   
   
   
   //为图片添加水印（各参数分别为:原图路径，水印图片路径，新图片路径(不指定时会覆盖原图)，水印透明度，水印图左上角距离原图左边的距离,水印图左上角距离原图上边的距离）
   public function water($source,$water,$savename=null,$alpha=80,$left='',$top='') {
        //检查文件是否存在
        if (!file_exists($source))
			{
			throw new OtionException("文件".$source."不存在");
            return false;
            }
		else
        if (!file_exists($water))
			{
			throw new OtionException("文件".$water."不存在");
            return false;
            }
        //图片信息
        $sInfo = $this->getImageInfo($source);
        $wInfo = $this->getImageInfo($water);

        //如果图片小于水印图片，不生成图片
        if ($sInfo["width"] < $wInfo["width"] || $sInfo['height'] < $wInfo['height'])
	    {
			throw new OtionException("原图小于水印图片");
            return false;
	    }
        //建立图像
        $sCreateFun = "imagecreatefrom" . $sInfo['type'];
        $sImage = $sCreateFun($source);
        $wCreateFun = "imagecreatefrom" . $wInfo['type'];
        $wImage = $wCreateFun($water);

        //设定图像的混色模式
        imagealphablending($wImage, true);

        //图像位置,若没有指定则默认为右下角右对齐
		if(!$top||$top>($sInfo["height"] - $wInfo["height"]))
        $posY = $sInfo["height"] - $wInfo["height"];
		else
		$posY = $top;

		if(!$left||$left>($sInfo["width"] - $wInfo["width"]))
        $posX = $sInfo["width"] - $wInfo["width"];
        else
		$posX=$left;

        //生成混合图像
        imagecopymerge($sImage, $wImage, $posX, $posY, 0, 0, $wInfo['width'], $wInfo['height'], $alpha);

        //输出图像
        $ImageFun = 'Image' . $sInfo['type'];
        //如果没有给出保存文件名，默认为原图像名
        if (!$savename)
		{
            $savename = $source;
            unlink($source);
        }
        //保存图像
        $ImageFun($sImage, $savename);
        imagedestroy($sImage);
    } 
}