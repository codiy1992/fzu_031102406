<?php     
class LineReport
{     
 private $width=250;//报表宽度
 private $height=150;//报表高度

 private $background='silver';//报表的背景颜色
 private $background_image;//背景图片
 
 private $title='This is a report form';//报表标题
 private $title_size=14;//报表标题的大小
 private $title_color='black';//报表标题的颜色

 private $smooth=true;//是否设置图线的平滑状态
 private $data;//统计数据

 private $margin;//显示区域与左、右、上、下距边线的距离,单位为像素,若不设置则自适应
 private $shadow=false;//是否显示画布阴影

 private $x_title;//设置x轴标题
 private $x_title_size=7;//设置x轴标题大小
 private $x_title_color='black';//设置x轴标题颜色

 private $x_data;//设置x轴上的文字
 private $x_data_size=7;//x轴上文字的大小
 private $x_data_color='black';//x轴上文字的颜色

 private $y_title;//设置y轴标题
 private $y_title_size=7;//设置y轴标题大小
 private $y_title_color='black';//设置y轴标题颜色

 private $mark_size=4;//数据标记点的大小
 private $mark_color='red';//数据标记点的颜色

 private $line_color='blue';//折线颜色

 private $y_color=true;//是否以不同颜色标记y轴分区
 private $y_color1='white';//用于标记分区的颜色1
 private $y_color2='#F7F7F7';//用于标记分区的颜色2

 private $save_as_file=false;//是否将生成的图片保存为文件
 private $save_path;//图片保存路径

 private static $instance=null;//保存自身实例(单例模式)

 public static function getInstance()//返回一个自身的实例(单例模式)
 {
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }
  return self::$instance;
 }
 private function __clone(){}

 private function _construct(){}

 public function get_attribute($name)//读取属性值
 {
 if(isset($this->$name)) 
     return $this->$name;
 else
	throw new OtionException('属性'.$name.'不存在！');
 }
 public function set_attribute($name,$value)//设置属性值
 {
 $this->$name=$value;
 }
 
 public function create()//生成报表
 {
require_once (otion_path.'/Extend/data/jpgraph/jpgraph.php');
require_once (otion_path.'/Extend/data/jpgraph/jpgraph_line.php');

$graph = new Graph($this->get_attribute('width'),$this->get_attribute('height'));//创建画布
if($this->get_attribute('smooth')==true) //设置折线的平滑状态
{ 
$graph->img->SetAntiAliasing();    
}
$graph->SetScale('textlin');//设置刻度模式
       

$graph->SetMarginColor($this->get_attribute('background'));//设置整张报表的背景色(也可以写#0000FF等)
if(isset($this->background_image)) //添加背景图片
{
$graph->SetBackgroundImage($this->get_attribute('background_image'),BGIMG_FILLFRAME);
}
$graph->title->Set($this->get_attribute('title'));//设置报表标题
$graph->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('title_size'));//设置标题的大小
$graph->title->setColor($this->get_attribute('title_color'));//设置标题的颜色

if(isset($this->margin))//设置显示区域左、右、上、下距边线的距离,单位为像素,若不设置则自适应
{
$m=$this->get_attribute('margin');
$graph->img->SetMargin($m[0],$m[1],$m[2],$m[3]);
}
if($this->get_attribute('y_color')==true) //以不同颜色标记y轴上的分区
{
$graph->ygrid->SetFill(true,$this->get_attribute('y_color1'),$this->get_attribute('y_color2'));
}

if(isset($this->x_title))//设置x轴标题
{
$graph->xaxis->title->Set($this->get_attribute('x_title'));
$graph->xaxis->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('x_title_size'));
$graph->xaxis->title->setColor($this->get_attribute('x_title_color'));
}

if(isset($this->x_data))//设置x轴上的文字,若不设置则填充以自增长的数字
{
$graph->xaxis->SetTickLabels($this->get_attribute('x_data'));
$graph->xaxis->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('x_data_size'));
$graph->xaxis->setColor($this->get_attribute('x_data_color'));
}

if(isset($this->y_title))//设置y轴标题
{
$graph->yaxis->title->Set($this->get_attribute('y_title'));
$graph->yaxis->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('y_title_size'));
$graph->yaxis->setColor($this->get_attribute('y_title_color'));
}

   
$p=new LinePlot($this->get_attribute('data'));     //创建折线图对象

$p->mark->SetType(MARK_FILLEDCIRCLE);    //设置数据标记点的样式
$p->mark->SetWidth($this->get_attribute('mark_size'));      //设置数据标记点的大小
$p->mark->SetFillColor($this->get_attribute('mark_color'));     //设置数据标记点的颜色

$p->SetColor($this->get_attribute('line_color'));//设置折形颜色
$p->SetCenter();      //在X轴的各坐标点中心位置绘制折线
$graph->Add($p);      //在统计图上绘制折线

if($this->get_attribute('shadow')==true) //创建画布阴影
{
$graph->SetShadow(); 
}
if($this->get_attribute('save_as_file')==false)
$graph->Stroke();  //将图像输出到浏览器
else
$graph->Stroke($this->get_attribute('save_path'));//将图像保存为文件  
 }

}    
 