<?php     
class ColumbReport
{     
 private $width=250;//报表宽度
 private $height=150;//报表高度

 private $background='silver';//报表的背景颜色
 private $background_image;//背景图片

 private $title='This is a report form';//报表标题
 private $title_size=14;//报表标题的大小
 private $title_color='black';//报表标题的颜色

 private $datay1=array(20,30);//柱形的下半部分高度
 private $datay1_color='AntiqueWhite2';//柱形下半部分的颜色
 private $datay1_border_color='darkred';//柱形的下半部分的边框颜色
 private $datay1_show_data=false;//是否显示柱形下半部分的数值
 private $datay1_data_format;//柱形下半部分数值的格式

 private $datay2=array(1,1);//柱形的上半部分高度
 private $datay2_border_color='blue';//柱形的上半部分的边框颜色
 private $datay2_color='olivedrab1';//柱形上半部分的颜色
 private $datay2_show_data=false;//是否显示柱形上半部分的数值
 private $datay2_data_format;//柱形上半部分数值的格式

 private $margin;//显示区域与左、右、上、下距边线的距离,单位为像素,若不设置则自适应
 private $shadow=false;//是否显示画布阴影

 private $x_title;//设置x轴标题
 private $x_title_size=7;//设置x轴标题大小
 private $x_title_color='black';//设置x轴标题颜色
 private $x_data;//设置x轴上的文字
 private $x_data_size=7;//x轴上文字的大小
 private $x_data_color='black';//x轴上文字的颜色

 private $y_title;//设置y轴标题
 private $y_title_size=7;//设置y轴标题大小
 private $y_title_color='black';//设置y轴标题颜色
 private $y_space;//y轴长度单位,若不设置则自适应

 private $save_as_file=false;//是否将生成的图片保存为文件
 private $save_path;//图片保存路径

 private static $instance=null;//保存自身实例(单例模式)

 public static function getInstance()//返回一个自身的实例(单例模式)
 {
  if(is_null(self::$instance))
  {
  self::$instance=new self;
  }
  return self::$instance;
 }
 private function __clone(){}

 private function _construct(){}

 public function get_attribute($name)//读取属性值
 {
 if(isset($this->$name)) 
     return $this->$name;
 else
	throw new OtionException('属性'.$name.'不存在！');
 }
 public function set_attribute($name,$value)//设置属性值
 {
 $this->$name=$value;
 }
 
 public function create()//生成报表
 {
 require_once (otion_path.'/Extend/data/jpgraph/jpgraph.php');
 require_once (otion_path.'/Extend/data/jpgraph/jpgraph_bar.php');


$graph = new Graph($this->get_attribute('width'),$this->get_attribute('height'));//设置整张报表的宽度和高度
$graph->SetScale('textlin');//设置刻度模式

$graph->SetMarginColor($this->get_attribute('background'));//设置整张报表的背景色(也可以写#0000FF等)
if(isset($this->background_image)) //添加背景图片
{
$graph->SetBackgroundImage($this->get_attribute('background_image'),BGIMG_FILLFRAME);
}

$graph->title->Set($this->get_attribute('title'));//设置报表标题
$graph->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('title_size'));//设置标题的大小
$graph->title->setColor($this->get_attribute('title_color'));//设置标题的颜色

// 设置柱形的下半部分
$bplot = new BarPlot($this->get_attribute('datay1'));//创建矩形对象
$bplot->SetFillGradient($this->get_attribute('datay1_color'),'AntiqueWhite4:0.8',GRAD_VERT);//设置柱形图的颜色
$bplot->SetColor($this->get_attribute('datay1_border_color'));//设置柱形图的边框颜色
if($this->get_attribute('datay1_show_data')==true)//显示柱形图的值
{
$bplot->value->Show();
if(isset($this->datay1_data_format))//设置柱形图数值的格式
  $bplot->value->SetFormat($this->get_attribute('datay1_data_format'));
}


//设置柱形的上半部分
$bplot2 = new BarPlot($this->get_attribute('datay2'));//创建矩形对象
$bplot2->SetFillGradient($this->get_attribute('datay2_color'),'AntiqueWhite4:0.8',GRAD_VERT);//设置柱形图的颜色
$bplot2->SetColor($this->get_attribute('datay2_border_color'));//设置柱形图的边框颜色
if($this->get_attribute('datay2_show_data')==true)//显示柱形图的值
{
$bplot2->value->Show();
if(isset($this->datay2_data_format))//设置柱形图数值的格式
  $bplot->value->SetFormat($this->get_attribute('datay2_data_format'));
}

//整合上述对柱形的设置
$accbplot = new AccBarPlot(array($bplot,$bplot2));
$graph->Add($accbplot);//将矩形添加到画布中

if(isset($this->margin))//设置显示区域左、右、上、下距边线的距离,单位为像素,若不设置则自适应
{
$m=$this->get_attribute('margin');
$graph->img->SetMargin($m[0],$m[1],$m[2],$m[3]);
}

if(isset($this->x_title))//设置x轴标题
{
$graph->xaxis->title->Set($this->get_attribute('x_title'));
$graph->xaxis->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('x_title_size'));
$graph->xaxis->title->setColor($this->get_attribute('x_title_color'));
}
if(isset($this->x_data))//设置x轴上的文字,若不设置则填充以自增长的数字
{
$graph->xaxis->SetTickLabels($this->get_attribute('x_data'));
$graph->xaxis->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('x_data_size'));
$graph->xaxis->setColor($this->get_attribute('x_data_color'));
}

if(isset($this->y_title))//设置y轴标题
{
$graph->yaxis->title->Set($this->get_attribute('y_title'));
$graph->yaxis->title->setFont(FF_SIMSUN,FS_BOLD,$this->get_attribute('y_title_size'));
$graph->yaxis->setColor($this->get_attribute('y_title_color'));
}
if(isset($this->y_space))//设置y轴单位长度,若不设置则自适应
{
$graph->yaxis->scale->SetGrace($this->get_attribute('y_space'));
}
if($this->get_attribute('shadow')==true) //创建画布阴影
{
$graph->SetShadow(); 
}
if($this->get_attribute('save_as_file')==false)
$graph->Stroke();  //将图像输出到浏览器
else
$graph->Stroke($this->get_attribute('save_path'));//将图像保存为文件  
 }

}    
 